#!/bin/sh

vaultwarden
