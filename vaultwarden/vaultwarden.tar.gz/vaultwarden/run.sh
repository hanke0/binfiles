#!/bin/bash

vaultwarden
