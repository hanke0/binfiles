"use strict";exports.id=50702,exports.ids=[50702],exports.modules={46627:(e,t,s)=>{s.d(t,{Z:()=>d});var i=s(88178),o=s(15348),a=s(44863),r=s(41602),n=s(61026),l=s(88494),p=s(45403);let d=(0,n.memo)(({title:e})=>i.jsx(l.D,{height:"100%",style:{userSelect:"none"},width:"100%",children:(0,i.jsxs)(p.Z,{flex:1,gap:12,width:"100%",children:[i.jsx(o.Z,{extra:"Chat",size:48,type:"combine"}),(0,i.jsxs)(p.Z,{gap:16,horizontal:!0,children:[i.jsx(a.Z,{icon:r.Z,spin:!0}),e]})]})}))},85752:(e,t,s)=>{s.d(t,{Z:()=>h});var i=s(88178),o=s(15348),a=s(10897),r=s(76054),n=s(2488),l=s(61026),p=s(49773),d=s(13488);let x=({size:e,img:t,type:s="image/webp"})=>{let i=document.createElement("canvas"),o=i.getContext("2d"),a=0,r=0;return t.width>t.height?a=(t.width-t.height)/2:r=(t.height-t.width)/2,i.width=e,i.height=e,o.drawImage(t,a,r,Math.min(t.width,t.height),Math.min(t.width,t.height),0,0,e,e),i.toDataURL(s)},c=e=>t=>{let s=new FileReader;s.readAsDataURL(t),s.addEventListener("load",()=>{e(String(s.result))})},g=(0,r.kc)(({css:e,token:t})=>e`
    cursor: pointer;
    overflow: hidden;
    border-radius: 50%;
    transition:
      scale 400ms ${t.motionEaseOut},
      box-shadow 100ms ${t.motionEaseOut};

    &:hover {
      box-shadow: 0 0 0 3px ${t.colorText};
    }

    &:active {
      scale: 0.8;
    }
  `),h=(0,l.memo)(({size:e=40,compressSize:t=256,style:s,id:r})=>{let{styles:l}=g(),[h,m]=(0,p.s)(e=>[d.k.userAvatar(e),e.updateAvatar]),u=c(e=>{let s=new Image;s.src=e,s.addEventListener("load",()=>{m(x({img:s,size:t}))})});return i.jsx("div",{className:l,id:r,style:{maxHeight:e,maxWidth:e,...s},children:i.jsx(a.Z,{beforeUpload:u,itemRender:()=>void 0,maxCount:1,children:h?i.jsx(n.default,{alt:"avatar",height:e,src:h,width:e}):i.jsx(o.Z,{size:e})})})})},13790:(e,t,s)=>{s.d(t,{Z:()=>j});var i,o=s(88178),a=s(44863),r=s(108),n=s(42130),l=s(4062),p=s(10897),d=s(76054),x=s(36738),c=s(33349),g=s(61026),h=s(60634),m=s(45403),u=s(88494),$=s(43412),w=s(86511);let S=(0,d.kc)(({css:e,token:t,prefixCls:s,isDarkMode:i})=>({modalTitle:e`
    &.${s}-modal-header {
      height: 80px;
      background:
        linear-gradient(
          180deg,
          ${(0,w.m4)(t.colorBgElevated,0)},
          ${t.colorBgContainer} ${i?"80":"140"}px
        ),
        fixed 0 0 /10px 10px radial-gradient(${t.colorFill} 1px, transparent 0);
    }

    & .${s}-modal-title {
      font-size: 24px;
    }
  `})),b=(0,g.memo)(({icon:e,onOpenChange:t,title:s,open:i,children:r,width:n=550})=>{let{styles:l}=S();return o.jsx($.Z,{afterOpenChange:t,centered:!0,classNames:{header:l.modalTitle},closable:!1,footer:null,open:i,title:(0,o.jsxs)(u.D,{gap:8,horizontal:!0,children:[o.jsx(a.Z,{icon:e}),s]}),width:n,children:r})});var v=s(46588);let y=(0,d.kc)(({css:e,token:t})=>({loader:e`
      transform: translateX(-${56}px);

      aspect-ratio: 1;
      width: 6px;

      color: ${t.colorPrimary};

      border-radius: 50%;
      box-shadow:
        ${28}px -${28}px 0 0,
        ${56}px -${28}px 0 0,
        ${84}px -${28}px 0 0,
        ${28}px 0 0 5px,
        ${56}px 0 0 5px,
        ${84}px 0 0 5px,
        ${28}px ${28}px 0 0,
        ${56}px ${28}px 0 0,
        ${84}px ${28}px 0 0;

      animation: loading 2s infinite linear;

      @keyframes loading {
        12.5% {
          box-shadow:
            ${28}px -${28}px 0 0,
            ${56}px -${28}px 0 0,
            ${84}px -${28}px 0 5px,
            ${28}px 0 0 5px,
            ${56}px 0 0 0,
            ${84}px 0 0 5px,
            ${28}px ${28}px 0 0,
            ${56}px ${28}px 0 0,
            ${84}px ${28}px 0 0;
        }

        25% {
          box-shadow:
            ${28}px -${28}px 0 5px,
            ${56}px -${28}px 0 0,
            ${84}px -${28}px 0 5px,
            ${28}px 0 0 0,
            ${56}px 0 0 0,
            ${84}px 0 0 0,
            ${28}px ${28}px 0 0,
            ${56}px ${28}px 0 5px,
            ${84}px ${28}px 0 0;
        }

        50% {
          box-shadow:
            ${28}px -${28}px 0 5px,
            ${56}px -${28}px 0 5px,
            ${84}px -${28}px 0 0,
            ${28}px 0 0 0,
            ${56}px 0 0 0,
            ${84}px 0 0 0,
            ${28}px ${28}px 0 0,
            ${56}px ${28}px 0 0,
            ${84}px ${28}px 0 5px;
        }

        62.5% {
          box-shadow:
            ${28}px -${28}px 0 0,
            ${56}px -${28}px 0 0,
            ${84}px -${28}px 0 0,
            ${28}px 0 0 5px,
            ${56}px 0 0 0,
            ${84}px 0 0 0,
            ${28}px ${28}px 0 0,
            ${56}px ${28}px 0 5px,
            ${84}px ${28}px 0 5px;
        }

        75% {
          box-shadow:
            ${28}px -${28}px 0 0,
            ${56}px -${28}px 0 5px,
            ${84}px -${28}px 0 0,
            ${28}px 0 0 0,
            ${56}px 0 0 0,
            ${84}px 0 0 5px,
            ${28}px ${28}px 0 0,
            ${56}px ${28}px 0 0,
            ${84}px ${28}px 0 5px;
        }

        87.5% {
          box-shadow:
            ${28}px -${28}px 0 0,
            ${56}px -${28}px 0 5px,
            ${84}px -${28}px 0 0,
            ${28}px 0 0 0,
            ${56}px 0 0 5px,
            ${84}px 0 0 0,
            ${28}px ${28}px 0 5px,
            ${56}px ${28}px 0 0,
            ${84}px ${28}px 0 0;
        }
      }
    `}));!function(e){e[e.Start=0]="Start",e[e.Loading=1]="Loading",e[e.Finished=2]="Finished",e[e.Close=3]="Close"}(i||(i={}));let j=(0,g.memo)(({children:e,onFinishImport:t})=>{let{t:s}=(0,h.$G)("common"),{importConfig:i}=(0,v.c)(),[d,$]=(0,g.useState)(0),[w,S]=(0,g.useState)(0),[j,f]=(0,g.useState)(),{styles:k}=y();return(0,o.jsxs)(o.Fragment,{children:[o.jsx(b,{icon:x.Z,open:1===w||2===w,title:s("importModal.title"),width:2===w?500:400,children:o.jsx(m.Z,{gap:24,padding:40,style:{paddingBlock:2===w?0:void 0},children:2===w?o.jsx(r.ZP,{extra:o.jsx(n.ZP,{onClick:()=>{S(3),t?.()},size:"large",type:"primary",children:s("importModal.finish.start")}),icon:o.jsx(a.Z,{icon:c.Z}),status:"success",style:{paddingBlock:24},subTitle:j?(0,o.jsxs)(u.D,{gap:16,width:400,children:[s("importModal.finish.subTitle",{duration:(d/1e3).toFixed(2)}),o.jsx(l.Z,{bordered:!0,columns:[{dataIndex:"title",title:s("importModal.result.type")},{dataIndex:"added",title:s("importModal.result.added")},{dataIndex:"skips",title:s("importModal.result.skips")},{dataIndex:"error",title:s("importModal.result.errors")}],dataSource:Object.entries(j).map(([e,t])=>({added:t.added,error:t.errors,skips:t.skips,title:s(`importModal.result.${e}`)})),pagination:!1,size:"small"})]}):s("importModal.finish.onlySettings"),title:s("importModal.finish.title")}):(0,o.jsxs)(o.Fragment,{children:[o.jsx(m.Z,{style:{height:80},children:o.jsx("div",{className:k.loader})}),o.jsx("p",{children:s("importModal.loading")})]})})}),o.jsx(p.Z,{beforeUpload:async e=>{S(1);let t=Date.now(),s=await i(e);return s&&f(s),$(Date.now()-t),S(2),!1},maxCount:1,showUploadList:!1,children:e})]})})},46588:(e,t,s)=>{s.d(t,{c:()=>l});var i=s(61026),o=s(11271),a=s(90770),r=s(47234),n=s(76632);let l=()=>{let e=(0,r.F)(e=>e.refreshSessions),[t,s]=(0,a.a)(e=>[e.refreshMessages,e.refreshTopic]),l=async i=>new Promise(a=>{(0,n.op)(i,async i=>{let r=await o.l.importConfigState(i);await e(),await t(),await s(),a(r)})});return(0,i.useMemo)(()=>({importConfig:l}),[])}},61420:(e,t,s)=>{s.d(t,{d:()=>o});var i=s(59586);let o=()=>{let{mobile:e}=(0,i.F)();return!!e}},69694:(e,t,s)=>{s.d(t,{Z:()=>B});var i=s(88178),o=s(76054),a=s(61026),r=s(88494),n=s(46819),l=s(85752),p=s(49773),d=s(44863),x=s(47312),c=s(42662),g=s(201),h=s(54838),m=s(66287),u=s(36486),$=s(10240),w=s(82463),S=s(64913),b=s(68243),v=s(81045),y=s(92924),j=s(12354),f=s(27426),k=s(20426),Z=s(60634),C=s(77072),A=s(13790),T=s(11271),M=s(17348);let F=(0,a.memo)(({tab:e,setTab:t})=>{let s=(0,k.useRouter)(),{t:o}=(0,Z.$G)("common"),[a,n]=(0,p.s)(e=>[e.hasNewVersion,e.useCheckLatestVersion]);n();let l=[{icon:i.jsx(d.Z,{icon:u.Z}),key:"import",label:i.jsx(A.Z,{children:o("import")})},{children:[{key:"allAgent",label:i.jsx("div",{children:o("exportType.allAgent")}),onClick:T.l.exportAgents},{key:"allAgentWithMessage",label:i.jsx("div",{children:o("exportType.allAgentWithMessage")}),onClick:T.l.exportSessions},{key:"globalSetting",label:i.jsx("div",{children:o("exportType.globalSetting")}),onClick:T.l.exportSettings},{type:"divider"},{key:"all",label:i.jsx("div",{children:o("exportType.all")}),onClick:T.l.exportAll}],icon:i.jsx(d.Z,{icon:$.Z}),key:"export",label:o("export")},{type:"divider"},{icon:i.jsx(d.Z,{icon:w.Z}),key:"feedback",label:o("feedback"),onClick:()=>window.open(C.eu,"__blank")},{icon:i.jsx(d.Z,{icon:S.Z}),key:"changelog",label:o("changelog"),onClick:()=>window.open(C.fM,"__blank")},{icon:i.jsx(d.Z,{icon:b.Z}),key:"wiki",label:"WIKI",onClick:()=>window.open(C.ts,"__blank")},{icon:i.jsx(d.Z,{icon:v.Z}),key:"about",label:o("about"),onClick:()=>window.open(C.FA,"__blank")},{type:"divider"},{icon:i.jsx(d.Z,{icon:y.Z}),key:"setting",label:(0,i.jsxs)(r.D,{align:"center",distribution:"space-between",gap:8,horizontal:!0,children:[o("setting")," ",a&&i.jsx(g.Z,{count:o("upgradeVersion.hasNew")})]}),onClick:()=>{t(M.i6.Setting),p.s.setState({settingsTab:M.v_.Common,sidebarKey:M.i6.Setting}),s.push("/settings/common")}}];return(0,i.jsxs)(i.Fragment,{children:[i.jsx(x.Z,{icon:c.Z,onClick:()=>window.open(C.qs,"__blank"),placement:"right",title:"Discord"}),i.jsx(x.Z,{icon:j.Z,onClick:()=>window.open(C.W3,"__blank"),placement:"right",title:"GitHub"}),i.jsx(h.Z,{arrow:!1,menu:{items:l},trigger:["click"],children:a?i.jsx(r.D,{children:i.jsx(m.ZP,{theme:{components:{Badge:{dotSize:8}}},children:i.jsx(g.Z,{dot:!0,offset:[-4,4],children:i.jsx(x.Z,{active:e===M.i6.Setting,icon:f.Z})})})}):i.jsx(x.Z,{active:e===M.i6.Setting,icon:f.Z})})]})});var I=s(94970),_=s(25861),G=s(46207),R=s(47234);let E=(0,a.memo)(({tab:e,setTab:t})=>{let{t:s}=(0,Z.$G)("common"),o=(0,p.s)(e=>e.switchBackToChat);return(0,i.jsxs)(i.Fragment,{children:[i.jsx(G.default,{href:"/chat",onClick:e=>{e.preventDefault(),o(R.F.getState().activeId),t(M.i6.Chat)},children:i.jsx(x.Z,{active:e===M.i6.Chat,icon:I.Z,placement:"right",size:"large",title:s("tab.chat")})}),i.jsx(G.default,{href:"/market",children:i.jsx(x.Z,{active:e===M.i6.Market,icon:_.Z,onClick:()=>{t(M.i6.Market)},placement:"right",size:"large",title:s("tab.market")})})]})}),z=(0,a.memo)(()=>{let[e,t]=(0,p.s)(e=>[e.sidebarKey,e.switchSideBar]);return i.jsx(n.Z,{avatar:i.jsx(l.Z,{id:"avatar"}),bottomActions:i.jsx(F,{setTab:t,tab:e}),style:{height:"100%"},topActions:i.jsx(E,{setTab:t,tab:e})})}),D=()=>!1,L=()=>{let[e,t]=(0,a.useState)(!1);return(0,a.useEffect)(()=>{t(D())},[]),e},B=(0,a.memo)(({children:e})=>{let t=L(),s=(0,o.Fg)();return(0,i.jsxs)(r.D,{height:"100%",horizontal:!0,style:t?{borderTop:`1px solid ${s.colorBorder}`}:{},width:"100%",children:[i.jsx(z,{}),e]})})},11271:(e,t,s)=>{s.d(t,{l:()=>c});var i=s(11098),o=s(2951),a=s(17657),r=s(49773),n=s(19031),l=s(47234),p=s(60496),d=s(76632);class x{constructor(){this.importSessions=async e=>await o.F.batchCreateSessions(e),this.importMessages=async e=>i.l.batchCreate(e),this.importSettings=async e=>{r.s.getState().importAppSettings(e)},this.importTopics=async e=>a.w.batchCreateTopics(e),this.importSessionGroups=async e=>o.F.batchCreateSessionGroups(e),this.importConfigState=async e=>{switch(e.exportType){case"settings":await this.importSettings(e.state.settings);break;case"agents":{let t=await this.importSessionGroups(e.state.sessionGroups),s=await this.importSessions(e.state.sessions);return{sessionGroups:this.mapImportResult(t),sessions:this.mapImportResult(s)}}case"all":{await this.importSettings(e.state.settings);let t=await this.importSessionGroups(e.state.sessionGroups),[s,i,o]=await Promise.all([this.importSessions(e.state.sessions),this.importMessages(e.state.messages),this.importTopics(e.state.topics)]);return{messages:this.mapImportResult(i),sessionGroups:this.mapImportResult(t),sessions:this.mapImportResult(s),topics:this.mapImportResult(o)}}case"sessions":{let t=await this.importSessionGroups(e.state.sessionGroups),[s,i,o]=await Promise.all([this.importSessions(e.state.sessions),this.importMessages(e.state.messages),this.importTopics(e.state.topics)]);return{messages:this.mapImportResult(i),sessionGroups:this.mapImportResult(t),sessions:this.mapImportResult(s),topics:this.mapImportResult(o)}}}},this.exportAgents=async()=>{let e=await o.F.getAllAgents(),t=await o.F.getSessionGroups(),s=(0,d.dl)("agents",{sessionGroups:t,sessions:e});(0,d._d)(s,"agents")},this.exportSessions=async()=>{let e=await o.F.getSessions(),t=await o.F.getSessionGroups(),s=await i.l.getAllMessages(),r=await a.w.getAllTopics(),n=(0,d.dl)("sessions",{messages:s,sessionGroups:t,sessions:e,topics:r});(0,d._d)(n,"sessions")},this.exportSingleSession=async e=>{let t=this.getSession(e);if(!t)return;let s=await i.l.getAllMessagesInSession(e),o=await a.w.getTopics({sessionId:e}),r=(0,d.dl)("singleSession",{messages:s,sessions:[t],topics:o});(0,d._d)(r,`${t.meta?.title}-session`)},this.exportSingleTopic=async(e,t)=>{let s=this.getSession(e);if(!s)return;let o=await i.l.getMessages(e,t),r=(await a.w.getTopics({sessionId:e})).find(e=>e.id===t);if(!r)return;let n=(0,d.dl)("singleSession",{messages:o,sessions:[s],topics:[r]});(0,d._d)(n,`${r.title}-topic`)},this.exportSingleAgent=async e=>{let t=this.getAgent(e);if(!t)return;let s=(0,d.dl)("agents",{sessionGroups:[],sessions:[t]});(0,d._d)(s,t.meta?.title||"agent")},this.exportSettings=async()=>{let e=this.getSettings(),t=(0,d.dl)("settings",{settings:e});(0,d._d)(t,"settings")},this.exportAll=async()=>{let e=await o.F.getSessions(),t=await o.F.getSessionGroups(),s=await i.l.getAllMessages(),r=await a.w.getAllTopics(),n=this.getSettings(),l=(0,d.dl)("all",{messages:s,sessionGroups:t,sessions:e,settings:n,topics:r});(0,d._d)(l,"config")},this.getSettings=()=>n.H.exportSettings(r.s.getState()),this.getSession=e=>p.y.getSessionById(e)(l.F.getState()),this.getAgent=e=>p.y.getSessionById(e)(l.F.getState()),this.mapImportResult=e=>({added:e.added,errors:e.errors?.length||0,skips:e.skips.length})}}let c=new x},76632:(e,t,s)=>{s.d(t,{dl:()=>g,_d:()=>x,op:()=>c});var i=s(31396);class o{migrate(e){let{sessions:t}=e.state;return{...e,state:{...e.state,sessionGroups:[],sessions:t.map(e=>this.migrateSession(e))}}}constructor(){this.version=2,this.migrateSession=e=>({...e,group:"default",pinned:"pinned"===e.group})}}var a=s(22044);class r{constructor(e,t=e.length){this.migrations=e.map(e=>new e).sort((e,t)=>e.version-t.version),this.targetVersion=t}migrate(e){let t=e,s=this.targetVersion||this.migrations.length;if(void 0===e.version)throw Error((0,a.t)("migrateError.missVersion",{ns:"migration"}));let i=e.version;for(let e=i||0;e<s;e++){let s=this.migrations.find(t=>t.version===e);if(!s)throw Error((0,a.t)("migrateError.noMigration",{ns:"migration"}));t=s.migrate(t),t.version+=1,console.debug("迁移器：",s,"数据：",t,"迁移后版本:",t.version)}return t}}class n{migrate(e){return e}constructor(){this.version=0}}var l=s(41040);class p{migrate(e){let{sessions:t={},inbox:s}=e.state,i=[],o=[],a=Object.values(t).map(e=>this.migrateSession(e,i,o));return s&&this.migrateSession({...s,id:l.B9},i,o),{...e,state:{...e.state,messages:i,sessions:a,topics:o}}}constructor(){this.version=1,this.migrateSession=(e,t,s)=>{let{chats:i,topics:o,createAt:a,updateAt:r,pinned:n,...l}=e;if(i)for(let e of Object.values(i))t.push(this.migrationMessage(e,l.id));if(o)for(let e of Object.values(o))s.push(this.migrationTopic(l.id,e));return{...l,createdAt:a,group:n?"pinned":"default",updatedAt:r}},this.migrationMessage=({createAt:e,extra:t,updateAt:s,name:i,function_call:o,...a},r)=>({...a,createdAt:e,plugin:o?{apiName:o.name,arguments:o.arguments,identifier:i,type:"default"}:a.plugin,sessionId:r,updatedAt:s,...t}),this.migrationTopic=(e,{createAt:t,updateAt:s,...i})=>({...i,createdAt:t,sessionId:e,updatedAt:s})}}let d=new r([o,p,n],3),x=(e,t)=>{let s=`LobeChat-${t||"-config"}-v3.json`,i=new Blob([JSON.stringify(e)],{type:"application/json"}),o=URL.createObjectURL(i),a=document.createElement("a");a.href=o,a.download=s,document.body.append(a),a.click(),URL.revokeObjectURL(o),a.remove()},c=(e,t)=>{e.text().then(e=>{try{let s=JSON.parse(e),{state:i}=d.migrate(s);t({...s,state:i})}catch(e){console.error(e),i.ZP.error({description:`出错原因: ${e.message}`,message:"导入失败"})}})},g=(e,t)=>{switch(e){case"agents":return{exportType:"agents",state:t,version:d.targetVersion};case"sessions":case"singleSession":return{exportType:"sessions",state:t,version:d.targetVersion};case"settings":return{exportType:"settings",state:t,version:d.targetVersion};case"all":return{exportType:"all",state:t,version:d.targetVersion}}throw Error("缺少正确的导出类型，请检查实现...")}},86003:(e,t,s)=>{s.d(t,{s:()=>a});var i=s(19575),o=s(57661);let a=()=>{if("undefined"==typeof process)throw Error("[Server method] you are importing a server-only module outside of server");let{get:e}=(0,i.headers)(),t=e("user-agent");return"mobile"===new o.UAParser(t||"").getDevice().type}}};