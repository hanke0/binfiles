"use strict";exports.id=16026,exports.ids=[16026],exports.modules={16026:(e,t,a)=>{a.r(t),a.d(t,{default:()=>d});var r=a(88178),s=a(13765),l=a(61026),n=a(38570),i=a(79221),o=a(23990),c=a(81882);let d=(0,l.memo)(()=>{let[e,t]=(0,i.F)(e=>[o._.showSideBar(e),e.deactivateAgent]),{t:a}=(0,n.$G)("market");return r.jsx(s.Z,{allowFullscreen:!0,onCancel:t,open:e,styles:{body:{padding:0}},title:a("sidebar.title"),children:r.jsx(c.Z,{})})})},81882:(e,t,a)=>{a.d(t,{Z:()=>I});var r,s=a(88178),l=a(61026),n=a(88494),i=a(61885),o=a(2647),c=a(38570),d=a(79221),m=a(73228),p=a(98606);let x=(0,l.memo)(({identifier:e})=>s.jsx(p.Z,{category:"General",categoryId:"DIC_kwDOKON5YM4CZNRJ",id:"lobehub",mapping:"specific",repo:"lobehub/lobe-chat-agents",repoId:"R_kgDOKON5YA",term:e}));var g=a(49370),h=a(62979),j=a(76701),u=a(66679),v=a(37854),y=a(10926),Z=a(45403),f=a(23990),k=a(47234),b=a(36315);let w=(0,b.kc)(({css:e,token:t,prefixCls:a,stylish:r})=>({author:e`
    font-size: 12px;
  `,avatar:e`
    flex: none;
  `,container:e`
    position: relative;
    padding: 16px 16px 24px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
  `,date:e`
    font-size: 12px;
    color: ${t.colorTextDescription};
  `,desc:e`
    color: ${t.colorTextDescription};
    text-align: center;
  `,loading:e`
    .${a}-skeleton-content {
      display: flex;
      flex-direction: column;
    }
  `,markdown:r.markdownInChat,nav:e`
    padding-top: 8px;
  `,title:e`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),{Link:N}=j.default,z=(0,l.memo)(()=>{let{t:e}=(0,c.$G)("market"),{styles:t,theme:a}=w(),r=(0,k.F)(e=>e.createSession),l=(0,d.F)(f._.currentAgentItem),{message:n}=u.Z.useApp(),{meta:i,createAt:o,author:m,homepage:p,config:x}=l,{avatar:j,title:b,description:z,tags:D,backgroundColor:B}=i;return(0,s.jsxs)(Z.Z,{className:t.container,gap:16,children:[s.jsx(g.Z,{animation:!0,avatar:j,background:B||a.colorFillTertiary,className:t.avatar,size:100}),s.jsx("div",{className:t.title,children:b}),s.jsx(Z.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:D.map((e,t)=>s.jsx(h.Z,{onClick:()=>d.F.setState({searchKeywords:e}),style:{margin:0},children:(0,y.Z)(e).trim()},t))}),s.jsx("div",{className:t.desc,children:z}),(0,s.jsxs)(N,{"aria-label":m,className:t.author,href:p,target:"_blank",children:["@",m]}),s.jsx(v.ZP,{block:!0,onClick:()=>{l&&r({config:x,meta:i})},type:"primary",children:e("addAgentAndConverse")}),s.jsx(v.ZP,{block:!0,onClick:()=>{l&&(r({config:x,meta:i},!1),n.success(e("addAgentSuccess")))},children:e("addAgent")}),s.jsx("div",{className:t.date,children:o})]})});var D=a(60718);let B=(0,l.memo)(()=>{let{styles:e}=w();return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(Z.Z,{className:e.container,gap:16,style:{paddingTop:80},children:[s.jsx(D.Z.Avatar,{active:!0,shape:"circle",size:100}),s.jsx(D.Z,{active:!0,className:e.loading,paragraph:{rows:3,style:{alignItems:"center",display:"flex",flexDirection:"column"},width:["60%","80%","20%"]},title:{style:{alignSelf:"center",marginBottom:0},width:"50%"}}),s.jsx(D.Z.Button,{active:!0,block:!0}),s.jsx(D.Z.Button,{active:!0,block:!0}),s.jsx(D.Z,{active:!0,className:e.loading,paragraph:{rows:1,style:{alignItems:"center",display:"flex",flexDirection:"column",marginBottom:0},width:["20%"]},title:!1})]}),(0,s.jsxs)(Z.Z,{gap:16,style:{padding:16},children:[(0,s.jsxs)(n.D,{gap:16,horizontal:!0,children:[s.jsx(D.Z.Button,{active:!0,size:"small"}),s.jsx(D.Z.Button,{active:!0,size:"small"})]}),s.jsx(D.Z,{active:!0,paragraph:{rows:6},title:!1})]})]})});var F=a(75367);let A=(0,b.kc)(({css:e,token:t})=>e`
    padding: 2px 5px;

    font-size: 12px;
    line-height: 1;
    color: ${t.colorBgLayout};

    background: ${t.colorText};
    border-radius: 12px;
  `),C=(0,l.memo)(({systemRole:e})=>{let{styles:t}=A(),a=(0,F.e)(e);return s.jsx("div",{className:t,children:a})});!function(e){e.comment="comment",e.prompt="prompt"}(r||(r={}));let $=(0,l.memo)(()=>{let[e,t]=(0,d.F)(e=>[e.useFetchAgent,e.currentIdentifier]),{t:a}=(0,c.$G)("market"),[r,p]=(0,l.useState)("prompt"),{data:g,isLoading:h}=e(t),{styles:j}=w();if(h||!g?.meta)return s.jsx(B,{});let{config:u,meta:v,identifier:y}=g,{systemRole:Z}=u;return(0,s.jsxs)(s.Fragment,{children:[s.jsx(m.Z,{meta:v,size:400,style:{height:120,marginBottom:-60}}),s.jsx(z,{}),s.jsx(n.D,{align:"center",children:s.jsx(i.Z,{activeKey:r,className:j.nav,items:[{key:"prompt",label:(0,s.jsxs)(n.D,{align:"center",gap:8,horizontal:!0,children:[a("sidebar.prompt")," ",s.jsx(C,{systemRole:Z})]})},{key:"comment",label:a("sidebar.comment")}],onChange:p,variant:"compact"})}),(0,s.jsxs)(n.D,{style:{padding:16},children:["prompt"===r&&s.jsx(o.Z,{className:j.markdown,fullFeaturedCodeBlock:!0,children:Z}),"comment"===r&&s.jsx(x,{identifier:y})]})]})}),I=(0,l.memo)(()=>s.jsx(n.D,{children:s.jsx($,{})}))},75367:(e,t,a)=>{a.d(t,{e:()=>l});var r=a(61026),s=a(38952);let l=(e="")=>{let[t,a]=(0,r.useState)(0);return(0,r.useEffect)(()=>{(0,r.startTransition)(()=>{(0,s.W)(e).then(a).catch(()=>{a(e.length)})})},[e]),t}}};