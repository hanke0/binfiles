"use strict";exports.id=16026,exports.ids=[16026],exports.modules={16026:(e,t,a)=>{a.r(t),a.d(t,{default:()=>d});var r=a(88178),s=a(40246),l=a(61026),i=a(84812),n=a(79221),o=a(23990),c=a(81882);let d=(0,l.memo)(()=>{let[e,t]=(0,n.F)(e=>[o._.showSideBar(e),e.deactivateAgent]),{t:a}=(0,i.$G)("market");return r.jsx(s.Z,{allowFullscreen:!0,onCancel:t,open:e,styles:{body:{padding:0}},title:a("sidebar.title"),children:r.jsx(c.Z,{})})})},81882:(e,t,a)=>{a.d(t,{Z:()=>T});var r,s=a(88178),l=a(61026),i=a(88494),n=a(72641),o=a(74227),c=a(84812),d=a(79221),m=a(73228),p=a(5557);let x=(0,l.memo)(({identifier:e})=>s.jsx(p.Z,{category:"General",categoryId:"DIC_kwDOKON5YM4CZNRJ",id:"lobehub",mapping:"specific",repo:"lobehub/lobe-chat-agents",repoId:"R_kgDOKON5YA",term:e}));var g=a(37637),h=a(73249),j=a(3117),u=a(35123),v=a(42130),y=a(10926),Z=a(45403),f=a(49773),k=a(17348),b=a(23990),w=a(47234),N=a(57695);let z=(0,N.kc)(({css:e,token:t,prefixCls:a,stylish:r})=>({author:e`
    font-size: 12px;
  `,avatar:e`
    flex: none;
  `,container:e`
    position: relative;
    padding: 16px 16px 24px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
  `,date:e`
    font-size: 12px;
    color: ${t.colorTextDescription};
  `,desc:e`
    color: ${t.colorTextDescription};
    text-align: center;
  `,loading:e`
    .${a}-skeleton-content {
      display: flex;
      flex-direction: column;
    }
  `,markdown:r.markdownInChat,nav:e`
    padding-top: 8px;
  `,title:e`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),{Link:B}=j.default,D=(0,l.memo)(()=>{let{t:e}=(0,c.$G)("market"),{styles:t,theme:a}=z(),r=(0,w.F)(e=>e.createSession),l=(0,f.s)(e=>e.switchSideBar),i=(0,d.F)(b._.currentAgentItem),{message:n}=u.Z.useApp(),{meta:o,createAt:m,author:p,homepage:x,config:j}=i,{avatar:N,title:D,description:C,tags:F,backgroundColor:A}=o;return(0,s.jsxs)(Z.Z,{className:t.container,gap:16,children:[s.jsx(g.Z,{animation:!0,avatar:N,background:A||a.colorFillTertiary,className:t.avatar,size:100}),s.jsx("div",{className:t.title,children:D}),s.jsx(Z.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:F.map((e,t)=>s.jsx(h.Z,{onClick:()=>d.F.setState({searchKeywords:e}),style:{margin:0},children:(0,y.Z)(e).trim()},t))}),s.jsx("div",{className:t.desc,children:C}),(0,s.jsxs)(B,{"aria-label":p,className:t.author,href:x,target:"_blank",children:["@",p]}),s.jsx(v.ZP,{block:!0,onClick:()=>{i&&(r({config:j,meta:o}),l(k.i6.Chat))},type:"primary",children:e("addAgentAndConverse")}),s.jsx(v.ZP,{block:!0,onClick:()=>{i&&(r({config:j,meta:o},!1),n.success(e("addAgentSuccess")))},children:e("addAgent")}),s.jsx("div",{className:t.date,children:m})]})});var C=a(49342);let F=(0,l.memo)(()=>{let{styles:e}=z();return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(Z.Z,{className:e.container,gap:16,style:{paddingTop:80},children:[s.jsx(C.Z.Avatar,{active:!0,shape:"circle",size:100}),s.jsx(C.Z,{active:!0,className:e.loading,paragraph:{rows:3,style:{alignItems:"center",display:"flex",flexDirection:"column"},width:["60%","80%","20%"]},title:{style:{alignSelf:"center",marginBottom:0},width:"50%"}}),s.jsx(C.Z.Button,{active:!0,block:!0}),s.jsx(C.Z.Button,{active:!0,block:!0}),s.jsx(C.Z,{active:!0,className:e.loading,paragraph:{rows:1,style:{alignItems:"center",display:"flex",flexDirection:"column",marginBottom:0},width:["20%"]},title:!1})]}),(0,s.jsxs)(Z.Z,{gap:16,style:{padding:16},children:[(0,s.jsxs)(i.D,{gap:16,horizontal:!0,children:[s.jsx(C.Z.Button,{active:!0,size:"small"}),s.jsx(C.Z.Button,{active:!0,size:"small"})]}),s.jsx(C.Z,{active:!0,paragraph:{rows:6},title:!1})]})]})});var A=a(75367);let S=(0,N.kc)(({css:e,token:t})=>e`
    padding: 2px 5px;

    font-size: 12px;
    line-height: 1;
    color: ${t.colorBgLayout};

    background: ${t.colorText};
    border-radius: 12px;
  `),$=(0,l.memo)(({systemRole:e})=>{let{styles:t}=S(),a=(0,A.e)(e);return s.jsx("div",{className:t,children:a})});!function(e){e.comment="comment",e.prompt="prompt"}(r||(r={}));let I=(0,l.memo)(()=>{let[e,t]=(0,d.F)(e=>[e.useFetchAgent,e.currentIdentifier]),{t:a}=(0,c.$G)("market"),[r,p]=(0,l.useState)("prompt"),{data:g,isLoading:h}=e(t),{styles:j}=z();if(h||!g?.meta)return s.jsx(F,{});let{config:u,meta:v,identifier:y}=g,{systemRole:Z}=u;return(0,s.jsxs)(s.Fragment,{children:[s.jsx(m.Z,{meta:v,size:400,style:{height:120,marginBottom:-60}}),s.jsx(D,{}),s.jsx(i.D,{align:"center",children:s.jsx(n.Z,{activeKey:r,className:j.nav,items:[{key:"prompt",label:(0,s.jsxs)(i.D,{align:"center",gap:8,horizontal:!0,children:[a("sidebar.prompt")," ",s.jsx($,{systemRole:Z})]})},{key:"comment",label:a("sidebar.comment")}],onChange:p,variant:"compact"})}),(0,s.jsxs)(i.D,{style:{padding:16},children:["prompt"===r&&s.jsx(o.Z,{className:j.markdown,fullFeaturedCodeBlock:!0,children:Z}),"comment"===r&&s.jsx(x,{identifier:y})]})]})}),T=(0,l.memo)(()=>s.jsx(i.D,{children:s.jsx(I,{})}))},75367:(e,t,a)=>{a.d(t,{e:()=>l});var r=a(61026),s=a(38952);let l=(e="")=>{let[t,a]=(0,r.useState)(0);return(0,r.useEffect)(()=>{(0,r.startTransition)(()=>{(0,s.W)(e).then(a).catch(()=>{a(e.length)})})},[e]),t}}};