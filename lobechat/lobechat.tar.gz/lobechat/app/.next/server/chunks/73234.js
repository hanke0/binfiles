"use strict";exports.id=73234,exports.ids=[73234],exports.modules={12081:(e,o,n)=>{n.d(o,{Z:()=>G});var t=n(88178),i=n(61026),s=n(88494),r=n(69694),a=n(12954),l=n(17348),c=n(13446),p=n(57695),d=n(53562),u=n(35323),m=n(88735),g=n(99101),x=n(8419),h=n(84812),j=n(48864),k=n(47234),Z=n(4337);let f=(0,p.kc)(({css:e,token:o})=>({logo:e`
    fill: ${o.colorText};
  `,top:e`
    position: sticky;
    top: 0;
  `})),y=(0,i.memo)(()=>{let{styles:e}=f(),{t:o}=(0,h.$G)("chat"),[n]=(0,k.F)(e=>[e.createSession]);return(0,t.jsxs)(s.D,{className:e.top,gap:16,padding:16,children:[(0,t.jsxs)(s.D,{distribution:"space-between",horizontal:!0,children:[t.jsx(m.Z,{className:e.logo,size:36,type:"text"}),t.jsx(g.Z,{icon:x.Z,onClick:()=>n(),size:j.Ak,style:{flex:"none"},title:o("newAgent")})]}),t.jsx(Z.Z,{})]})}),v=(0,p.kc)(({stylish:e,css:o,cx:n})=>n(e.noScrollbar,o`
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 8px 8px 0;
    `)),S=(0,i.memo)(()=>{let{styles:e}=v();return(0,t.jsxs)(d.Z,{children:[t.jsx(y,{}),t.jsx(c.Z,{className:e,children:t.jsx(u.Z,{})})]})}),G=(0,i.memo)(({children:e})=>((0,a.C)(l.i6.Chat),(0,t.jsxs)(r.Z,{children:[t.jsx(S,{}),t.jsx(s.D,{flex:1,height:"100%",id:"lobe-conversion-container",style:{position:"relative"},children:e})]})))},10651:(e,o,n)=>{n.r(o),n.d(o,{default:()=>p});var t=n(51679),i=n(20426),s=n(29746),r=n(81801),a=n(61026),l=n(43147),c=n(47234);let p=(0,a.memo)(()=>{let e=(0,l.N)(c.F),{mobile:o}=(0,t.F)();e("isMobile",o),e("router",(0,i.useRouter)());let[n,p]=(0,s.v1)("session",r.Oi.withDefault("inbox").withOptions({history:"replace",throttleMs:500}));return e("activeId",n),(0,a.useEffect)(()=>{let e=c.F.subscribe(e=>e.activeId,e=>p(e));return()=>{e()}},[]),null})},35323:(e,o,n)=>{n.d(o,{Z:()=>eF});var t=n(88178),i=n(61026),s=n(47234),r=n(2752),a=n.n(r),l=n(84812),c=n(49773),p=n(41299),d=n(60496),u=n(75517),m=n(27599),g=n(99101),x=n(35123),h=n(54838),j=n(57695),k=n(16490),Z=n(79456),f=n(68898),y=n(51212),v=n(75806);let S=(0,j.kc)(({css:e})=>({modalRoot:e`
    z-index: 2000;
  `})),G=(0,i.memo)(({id:e,openRenameModal:o,openConfigModal:n,onOpenChange:r,isCustomGroup:a,isPinned:c})=>{let{t:p}=(0,l.$G)("chat"),{styles:d}=S(),{modal:u}=x.Z.useApp(),[j,G]=(0,s.F)(e=>[e.createSession,e.removeSessionGroup]),b={icon:t.jsx(m.Z,{icon:k.Z}),key:"config",label:p("sessionGroup.config"),onClick:({domEvent:e})=>{e.stopPropagation(),n()}},C={icon:t.jsx(m.Z,{icon:Z.Z}),key:"newAgent",label:p("newAgent"),onClick:({domEvent:o})=>{o.stopPropagation(),j({group:e,pinned:c})}},F=(0,i.useMemo)(()=>[C,{type:"divider"},{icon:t.jsx(m.Z,{icon:f.Z}),key:"rename",label:p("sessionGroup.rename"),onClick:({domEvent:e})=>{e.stopPropagation(),o?.()}},b,{type:"divider"},{danger:!0,icon:t.jsx(m.Z,{icon:y.Z}),key:"delete",label:p("delete",{ns:"common"}),onClick:({domEvent:o})=>{o.stopPropagation(),u.confirm({centered:!0,okButtonProps:{danger:!0},onOk:()=>{e&&G(e)},rootClassName:d.modalRoot,title:p("sessionGroup.confirmRemoveGroupAlert")})}}],[]),w=(0,i.useMemo)(()=>[C,{type:"divider"},b],[]);return t.jsx(h.Z,{arrow:!1,menu:{items:a?F:w,onClick:({domEvent:e})=>{e.stopPropagation()}},onOpenChange:r,trigger:["click"],children:t.jsx(g.Z,{icon:v.Z,onClick:e=>{e.stopPropagation()},size:{blockSize:22,fontSize:16},style:{marginRight:-8}})})});var b=n(23667),C=n(60883);let F=(0,j.kc)(({css:e,prefixCls:o,token:n,responsive:t})=>({container:e`
    .${o}-collapse-header {
      padding-inline: 16px 10px !important;
      color: ${n.colorTextDescription} !important;
      border-radius: ${n.borderRadius}px !important;

      ${t.mobile} {
        border-radius: 0 !important;
      }

      &:hover {
        color: ${n.colorText} !important;
        background: ${n.colorFillTertiary};
        .${o}-collapse-extra {
          display: block;
        }
      }
    }
    .${o}-collapse-extra {
      display: none;
    }
    .${o}-collapse-content {
      border-radius: 0 !important;
    }
    .${o}-collapse-content-box {
      padding: 0 !important;
    }
  `,icon:e`
    transition: all 100ms ${n.motionEaseOut};
  `})),w=(0,i.memo)(e=>{let{styles:o}=F();return t.jsx(b.Z,{bordered:!1,className:o.container,expandIcon:({isActive:e})=>t.jsx(m.Z,{className:o.icon,icon:C.Z,size:{fontSize:16},style:e?{}:{rotate:"-90deg"}}),expandIconPosition:"end",ghost:!0,size:"small",...e})});var $=n(51679),I=n(46207),z=n(75175),P=n(41040),A=n(77072),D=n(48543),M=n(37637),N=n(67570);let{Item:R}=D.default,B=(0,j.kc)(({css:e,token:o,responsive:n})=>({container:e`
      position: relative;

      margin-block: 2px;
      padding-right: 16px;
      padding-left: 8px;

      border-radius: ${o.borderRadius}px;
      ${n.mobile} {
        margin-block: 0;
        padding-left: 12px;
        border-radius: 0;
      }
    `})),O=(0,i.memo)(({avatar:e,avatarBackground:o,active:n,showAction:s,actions:r,...a})=>{let l=(0,i.useRef)(null),c=(0,N.Z)(l),{mobile:p}=(0,$.F)(),{styles:d}=B(),u=(0,i.useMemo)(()=>t.jsx(M.Z,{animation:c,avatar:e,background:o,shape:"circle",size:46}),[c,e,o]);return t.jsx(R,{actions:r,active:!p&&n,avatar:u,className:d.container,ref:l,showAction:r&&(c||s),...a})}),T=(0,i.memo)(()=>{let{t:e}=(0,l.$G)("chat"),{mobile:o}=(0,$.F)(),[n,i]=(0,s.F)(e=>[e.activeId,e.switchSession]);return t.jsx(I.default,{"aria-label":e("inbox.title"),href:(0,A.gj)(P.B9,o),onClick:e=>{e.preventDefault(),i(P.B9)},children:t.jsx(O,{active:n===P.B9,avatar:z.Jo,title:e("inbox.title")})})});var E=n(45336),L=n(42130),K=n(88494);let W=(0,i.memo)(({groupId:e})=>{let{t:o}=(0,l.$G)("chat"),n=(0,s.F)(e=>e.createSession);return t.jsx(K.D,{style:{margin:"12px 16px"},children:t.jsx(L.ZP,{block:!0,icon:t.jsx(m.Z,{icon:Z.Z}),onClick:()=>n({group:e}),children:o("newAgent")})})});var H=n(85954),J=n(47897),V=n(90770),X=n(19031),q=n(95650),Q=n(24130),U=n(40246),Y=n(36637);let _=(0,i.memo)(({id:e,open:o,onCancel:n})=>{let{t:r}=(0,l.$G)("chat"),a=(0,c.s)(e=>e.toggleExpandSessionGroup),{message:p}=x.Z.useApp(),[d,u]=(0,s.F)(e=>[e.updateSessionGroupId,e.addSessionGroup]),[m,g]=(0,i.useState)("");return t.jsx("div",{onClick:e=>e.stopPropagation(),children:t.jsx(U.Z,{allowFullscreen:!0,onCancel:n,onOk:async o=>{if(!m)return;if(0===m.length||m.length>20)return p.warning(r("sessionGroup.tooLong"));let t=await u(m);await d(e,t),a(t,!0),p.success(r("sessionGroup.createSuccess")),n?.(o)},open:o,title:r("sessionGroup.createGroup"),width:400,children:t.jsx(K.D,{paddingBlock:16,children:t.jsx(Y.I,{autoFocus:!0,onChange:e=>g(e.target.value),placeholder:r("sessionGroup.inputPlaceholder"),value:m})})})})});var ee=n(49297),eo=n(54933),en=n(64643),et=n(77193),ei=n(88300),es=n(33477),er=n(11271);let ea=e=>e.customSessionGroups.map(e=>({id:e.id,name:e.name})),el={getGroupById:e=>o=>ea(o).find(o=>o.id===e),sessionGroupItems:ea},ec=(0,j.kc)(({css:e})=>({modalRoot:e`
    z-index: 2000;
  `})),ep=(0,i.memo)(({group:e,id:o,openCreateGroupModal:n,setOpen:r})=>{let{styles:c}=ec(),{t:p}=(0,l.$G)("chat"),j=(0,s.F)(el.sessionGroupItems,a()),[k,f,S,G,b]=(0,s.F)(e=>{let n=d.y.getSessionById(o)(e);return[q.k.getSessionPinned(n),e.removeSession,e.pinSession,e.duplicateSession,e.updateSessionGroupId]}),{modal:C}=x.Z.useApp(),F=e===u.z.Default,w=(0,i.useMemo)(()=>[{icon:t.jsx(m.Z,{icon:k?ee.Z:eo.Z}),key:"pin",label:p(k?"pinOff":"pin"),onClick:()=>{S(o,!k)}},{icon:t.jsx(m.Z,{icon:en.Z}),key:"duplicate",label:p("duplicate",{ns:"common"}),onClick:({domEvent:e})=>{e.stopPropagation(),G(o)}},{type:"divider"},{children:[...j.map(({id:n,name:i})=>({icon:e===n?t.jsx(m.Z,{icon:et.Z}):t.jsx("div",{}),key:n,label:i,onClick:()=>{b(o,n)}})),{icon:F?t.jsx(m.Z,{icon:et.Z}):t.jsx("div",{}),key:"defaultList",label:p("defaultList"),onClick:()=>{b(o,u.z.Default)}},{type:"divider"},{icon:t.jsx(m.Z,{icon:Z.Z}),key:"createGroup",label:t.jsx("div",{children:p("sessionGroup.createGroup")}),onClick:({domEvent:e})=>{e.stopPropagation(),n()}}],icon:t.jsx(m.Z,{icon:ei.Z}),key:"moveGroup",label:p("sessionGroup.moveGroup")},{type:"divider"},{children:[{key:"agent",label:p("exportType.agent",{ns:"common"}),onClick:()=>{er.l.exportSingleAgent(o)}},{key:"agentWithMessage",label:p("exportType.agentWithMessage",{ns:"common"}),onClick:()=>{er.l.exportSingleSession(o)}}],icon:t.jsx(m.Z,{icon:es.Z}),key:"export",label:p("export",{ns:"common"})},{danger:!0,icon:t.jsx(m.Z,{icon:y.Z}),key:"delete",label:p("delete",{ns:"common"}),onClick:({domEvent:e})=>{e.stopPropagation(),C.confirm({centered:!0,okButtonProps:{danger:!0},onOk:()=>{f(o)},rootClassName:c.modalRoot,title:p("confirmRemoveSessionItemAlert")})}}],[o,k]);return t.jsx(h.Z,{arrow:!1,menu:{items:w,onClick:({domEvent:e})=>{e.stopPropagation()}},onOpenChange:r,trigger:["click"],children:t.jsx(g.Z,{icon:v.Z,size:{blockSize:28,fontSize:16}})})}),ed=(0,i.memo)(({id:e})=>{let[o,n]=(0,i.useState)(!1),[r,a]=(0,i.useState)(!1),[l]=(0,c.s)(e=>[X.H.defaultAgentConfig(e).model]),[p]=(0,s.F)(o=>[o.activeId===e]),[u]=(0,V.a)(o=>[!!o.chatLoadingId&&e===o.activeId]),[m,g,x,h,j,k,Z,f,y]=(0,s.F)(o=>{let n=d.y.getSessionById(e)(o),t=n.meta,i=n.config.systemRole;return[q.k.getSessionPinned(n),Q.y.getTitle(t),Q.y.getDescription(t),i,Q.y.getAvatar(t),t.backgroundColor,n?.updatedAt,n.config.model,n?.group]}),v=f!==l,S=(0,i.useMemo)(()=>t.jsx(ep,{group:y,id:e,openCreateGroupModal:()=>a(!0),setOpen:n}),[y,e]),G=(0,i.useMemo)(()=>v?t.jsx(K.D,{gap:4,horizontal:!0,style:{flexWrap:"wrap"},children:v&&t.jsx(J.Z,{model:f})}):void 0,[v,f]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(O,{actions:S,active:p,addon:G,avatar:j,avatarBackground:k,date:Z,description:x||h,loading:u,pin:m,showAction:o,title:g}),t.jsx(_,{id:e,onCancel:()=>a(!1),open:r})]})},H.X);var eu=n(49342);let em=(0,j.kc)(({css:e})=>({avatar:e``,paragraph:e`
    height: 12px !important;
    margin-top: 12px !important;

    > li {
      height: 12px !important;
    }
  `,title:e`
    height: 14px !important;
    margin-top: 4px !important;
    margin-bottom: 12px !important;

    > li {
      height: 14px !important;
    }
  `})),eg=()=>{let{styles:e}=em(),o=Array.from({length:4}).fill("");return t.jsx(K.D,{gap:8,paddingInline:16,children:o.map((o,n)=>t.jsx(eu.Z,{active:!0,avatar:!0,paragraph:{className:e.paragraph,rows:1},title:{className:e.title}},n))})},ex=(0,j.kc)(({css:e})=>e`
    min-height: 70px;
  `),eh=(0,i.memo)(({dataSource:e,groupId:o,showAddButton:n=!0})=>{let[i,r,a]=(0,s.F)(e=>[e.activeSession,e.switchSession,d.y.isSessionListInit(e)]),{styles:l}=ex(),{mobile:c}=(0,$.F)();return a?e.length>0?e.map(({id:e})=>t.jsx(E.Z,{className:l,children:t.jsx(I.default,{"aria-label":e,href:(0,A.gj)(e,c),onClick:o=>{o.preventDefault(),c?r(e):i(e)},children:t.jsx(ed,{id:e})})},e)):n&&t.jsx(W,{groupId:o}):t.jsx(eg,{})});var ej=n(50638),ek=n(39794),eZ=n(53597);let ef=(0,j.kc)(({css:e})=>({content:e`
    position: relative;
    overflow: hidden;
    flex: 1;
  `,title:e`
    flex: 1;
    height: 28px;
    line-height: 28px;
    text-align: start;
  `})),ey=(0,i.memo)(({id:e,name:o})=>{let{t:n}=(0,l.$G)("chat"),{styles:r}=ef(),{message:a}=x.Z.useApp(),[c,p]=(0,i.useState)(!1),[d,u]=(0,s.F)(e=>[e.updateSessionGroupName,e.removeSessionGroup]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(ej.Z.DragHandle,{}),c?t.jsx(ek.Z,{editing:c,onChangeEnd:t=>{if(o!==t){if(!t)return;if(0===t.length||t.length>20)return a.warning(n("sessionGroup.tooLong"));d(e,t),a.success(n("sessionGroup.renameSuccess"))}p(!1)},onEditingChange:e=>p(e),showEditIcon:!1,size:"small",style:{height:28},type:"pure",value:o}):(0,t.jsxs)(t.Fragment,{children:[t.jsx("span",{className:r.title,children:o}),t.jsx(g.Z,{icon:f.Z,onClick:()=>p(!0),size:"small"}),t.jsx(eZ.Z,{arrow:!1,okButtonProps:{danger:!0,type:"primary"},onConfirm:()=>{u(e)},title:n("sessionGroup.confirmRemoveGroupAlert"),children:t.jsx(g.Z,{icon:y.Z,size:"small"})})]})]})}),ev=(0,j.kc)(({css:e,token:o,stylish:n})=>({container:e`
    height: 36px;
    padding-inline: 8px;
    border-radius: ${o.borderRadius}px;
    transition: background 0.2s ease-in-out;

    &:hover {
      ${n.blur};
      background: ${o.colorFillTertiary};
    }
  `})),eS=(0,i.memo)(({open:e,onCancel:o})=>{let{t:n}=(0,l.$G)("chat"),{styles:i}=ev(),r=(0,s.F)(el.sessionGroupItems,a()),[c,p]=(0,s.F)(e=>[e.addSessionGroup,e.updateSessionGroupSort]);return t.jsx(U.Z,{allowFullscreen:!0,footer:null,onCancel:o,open:e,title:n("sessionGroup.config"),width:400,children:(0,t.jsxs)(K.D,{children:[t.jsx(ej.Z,{items:r,onChange:e=>{p(e)},renderItem:e=>t.jsx(ej.Z.Item,{align:"center",className:i.container,gap:4,horizontal:!0,id:e.id,justify:"space-between",children:t.jsx(ey,{...e})})}),t.jsx(L.ZP,{block:!0,icon:t.jsx(m.Z,{icon:Z.Z}),onClick:()=>c(n("sessionGroup.newGroup")),children:n("sessionGroup.createGroup")})]})})}),eG=(0,i.memo)(({id:e,open:o,onCancel:n})=>{let{t:r}=(0,l.$G)("chat"),c=(0,s.F)(e=>e.updateSessionGroupName),p=(0,s.F)(o=>el.getGroupById(e)(o),a()),[d,u]=(0,i.useState)(),{message:m}=x.Z.useApp();return t.jsx(U.Z,{allowFullscreen:!0,onCancel:n,onOk:o=>{if(d){if(0===d.length||d.length>20)return m.warning(r("sessionGroup.tooLong"));c(e,d),m.success(r("sessionGroup.renameSuccess")),n?.(o)}},open:o,title:r("sessionGroup.rename"),width:400,children:t.jsx(Y.I,{autoFocus:!0,defaultValue:p?.name,onChange:e=>u(e.target.value),placeholder:r("sessionGroup.inputPlaceholder"),value:d})})}),eb=(0,i.memo)(()=>{let{t:e}=(0,l.$G)("chat"),[o,n]=(0,i.useState)(),[r,m]=(0,i.useState)(!1),[g,x]=(0,i.useState)(!1),[h]=(0,s.F)(e=>[e.useFetchSessions]);h();let j=(0,s.F)(d.y.pinnedSessions,a()),k=(0,s.F)(d.y.defaultSessions,a()),Z=(0,s.F)(d.y.customSessionGroups,a()),[f,y]=(0,c.s)(e=>[p.l.sessionGroupKeys(e),e.updatePreference]),v=(0,i.useMemo)(()=>[j.length>0&&{children:t.jsx(eh,{dataSource:j}),extra:t.jsx(G,{isPinned:!0,openConfigModal:()=>x(!0)}),key:u.z.Pinned,label:e("pin")},...Z.map(({id:e,name:o,children:i})=>({children:t.jsx(eh,{dataSource:i,groupId:e}),extra:t.jsx(G,{id:e,isCustomGroup:!0,onOpenChange:o=>{o&&n(e)},openConfigModal:()=>x(!0),openRenameModal:()=>m(!0)}),key:e,label:o})),{children:t.jsx(eh,{dataSource:k}),extra:t.jsx(G,{openConfigModal:()=>x(!0)}),key:u.z.Default,label:e("defaultList")}].filter(Boolean),[Z,j,k]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(T,{}),t.jsx(w,{activeKey:f,items:v,onChange:e=>{y({expandSessionGroupKeys:"string"==typeof e?[e]:e})}}),o&&t.jsx(eG,{id:o,onCancel:()=>m(!1),open:r}),t.jsx(eS,{onCancel:()=>x(!1),open:g})]})}),eC=(0,i.memo)(()=>{let e=(0,s.F)(d.y.searchSessions,a());return t.jsx(eh,{dataSource:e,showAddButton:!1})}),eF=(0,i.memo)(()=>(0,s.F)(e=>e.isSearching)?t.jsx(eC,{}):t.jsx(eb,{}))},4337:(e,o,n)=>{n.d(o,{Z:()=>c});var t=n(88178),i=n(87657),s=n(51679),r=n(61026),a=n(84812),l=n(47234);let c=(0,r.memo)(()=>{let{t:e}=(0,a.$G)("chat"),[o,n]=(0,r.useState)(void 0),[c]=(0,l.F)(e=>[e.useSearchSessions]);c(o);let{mobile:p}=(0,s.F)();return t.jsx(i.Z,{allowClear:!0,enableShortKey:!p,onChange:e=>{let o=e.target.value;n(o),l.F.setState({isSearching:!!o})},placeholder:e("searchAgentPlaceholder"),shortKey:"k",spotlight:!p,type:p?"block":"ghost",value:o})})},48850:(e,o,n)=>{n.d(o,{Z:()=>l});var t=n(88178),i=n(61026),s=n(84812),r=n(46627),a=n(61420);let l=({children:e,Mobile:o})=>{let{t:n}=(0,s.$G)();return(0,a.d)()?t.jsx(i.Suspense,{fallback:t.jsx(r.Z,{title:n("layoutInitializing",{ns:"common"})}),children:t.jsx(o,{})}):e}},41299:(e,o,n)=>{n.d(o,{l:()=>t});let t={sessionGroupKeys:e=>e.preference.expandSessionGroupKeys||[],useCmdEnterToSend:e=>e.preference.useCmdEnterToSend||!1}}};