"use strict";exports.id=59808,exports.ids=[59808],exports.modules={47150:(e,o,n)=>{n.d(o,{Z:()=>$});var t=n(88178),i=n(61026),s=n(88494),r=n(69694),a=n(17348),l=n(441),c=n(36315),p=n(92369),d=n(33634),u=n(2752),m=n.n(u),g=n(48864),x=n(49773);let h=(0,c.kc)(({css:e,token:o})=>({panel:e`
    height: 100%;
    color: ${o.colorTextSecondary};
    background: ${o.colorBgContainer};
  `})),j=(0,i.memo)(({children:e})=>{let{styles:o}=h(),[n,s,r]=(0,x.s)(e=>[e.preference.sessionsWidth,e.preference.showSessionPanel,e.updatePreference]),[a,l]=(0,i.useState)(n);return a!==n&&l(n),t.jsx(p.Z,{className:o.panel,defaultSize:{width:a},expand:s,maxWidth:400,minWidth:g.QH,onExpandChange:e=>{r({sessionsWidth:e?320:0,showSessionPanel:e})},onSizeChange:(e,o)=>{if(!o)return;let t="string"==typeof o.width?Number.parseInt(o.width):o.width;m()(t,n)||(l(t),r({sessionsWidth:t}))},placement:"left",size:{height:"100%",width:n},children:t.jsx(d.Z,{style:{flex:"none",height:"100%",minWidth:g.QH},children:e})})});var k=n(35323),f=n(25925),Z=n(64108),y=n(21360),S=n(38570),v=n(47234),b=n(4337);let G=(0,c.kc)(({css:e,token:o})=>({logo:e`
    fill: ${o.colorText};
  `,top:e`
    position: sticky;
    top: 0;
  `})),C=(0,i.memo)(()=>{let{styles:e}=G(),{t:o}=(0,S.$G)("chat"),[n]=(0,v.F)(e=>[e.createSession]);return(0,t.jsxs)(s.D,{className:e.top,gap:16,padding:16,children:[(0,t.jsxs)(s.D,{distribution:"space-between",horizontal:!0,children:[t.jsx(f.Z,{className:e.logo,size:36,type:"text"}),t.jsx(Z.Z,{icon:y.Z,onClick:()=>n(),size:g.Ak,style:{flex:"none"},title:o("newAgent")})]}),t.jsx(b.Z,{})]})}),F=(0,c.kc)(({stylish:e,css:o,cx:n})=>n(e.noScrollbar,o`
      display: flex;
      flex-direction: column;
      gap: 2px;
      padding: 8px 8px 0;
    `)),w=(0,i.memo)(()=>{let{styles:e}=F();return(0,t.jsxs)(j,{children:[t.jsx(C,{}),t.jsx(l.Z,{className:e,children:t.jsx(k.Z,{})})]})}),$=(0,i.memo)(({children:e})=>(0,t.jsxs)(r.Z,{sidebarKey:a.i6.Chat,children:[t.jsx(w,{}),t.jsx(s.D,{flex:1,height:"100%",id:"lobe-conversion-container",style:{position:"relative"},children:e})]}))},10651:(e,o,n)=>{n.r(o),n.d(o,{default:()=>p});var t=n(28253),i=n(20426),s=n(30989),r=n(24027),a=n(61026),l=n(85759),c=n(47234);let p=(0,a.memo)(()=>{let e=(0,l.N)(c.F),{mobile:o}=(0,t.F)();e("isMobile",o),e("router",(0,i.useRouter)());let[n,p]=(0,s.v1)("session",r.Oi.withDefault("inbox").withOptions({history:"replace",throttleMs:500}));return e("activeId",n),(0,a.useEffect)(()=>{let e=c.F.subscribe(e=>e.activeId,e=>p(e));return()=>{e()}},[]),null})},35323:(e,o,n)=>{n.d(o,{Z:()=>eF});var t=n(88178),i=n(61026),s=n(47234),r=n(2752),a=n.n(r),l=n(38570),c=n(49773),p=n(41299),d=n(60496),u=n(75517),m=n(84098),g=n(64108),x=n(66679),h=n(18325),j=n(36315),k=n(89829),f=n(50226),Z=n(65325),y=n(6080),S=n(7950);let v=(0,j.kc)(({css:e})=>({modalRoot:e`
    z-index: 2000;
  `})),b=(0,i.memo)(({id:e,openRenameModal:o,openConfigModal:n,onOpenChange:r,isCustomGroup:a,isPinned:c})=>{let{t:p}=(0,l.$G)("chat"),{styles:d}=v(),{modal:u}=x.Z.useApp(),[j,b]=(0,s.F)(e=>[e.createSession,e.removeSessionGroup]),G={icon:t.jsx(m.Z,{icon:k.Z}),key:"config",label:p("sessionGroup.config"),onClick:({domEvent:e})=>{e.stopPropagation(),n()}},C={icon:t.jsx(m.Z,{icon:f.Z}),key:"newAgent",label:p("newAgent"),onClick:({domEvent:o})=>{o.stopPropagation(),j({group:e,pinned:c})}},F=(0,i.useMemo)(()=>[C,{type:"divider"},{icon:t.jsx(m.Z,{icon:Z.Z}),key:"rename",label:p("sessionGroup.rename"),onClick:({domEvent:e})=>{e.stopPropagation(),o?.()}},G,{type:"divider"},{danger:!0,icon:t.jsx(m.Z,{icon:y.Z}),key:"delete",label:p("delete",{ns:"common"}),onClick:({domEvent:o})=>{o.stopPropagation(),u.confirm({centered:!0,okButtonProps:{danger:!0},onOk:()=>{e&&b(e)},rootClassName:d.modalRoot,title:p("sessionGroup.confirmRemoveGroupAlert")})}}],[]),w=(0,i.useMemo)(()=>[C,{type:"divider"},G],[]);return t.jsx(h.Z,{arrow:!1,menu:{items:a?F:w,onClick:({domEvent:e})=>{e.stopPropagation()}},onOpenChange:r,trigger:["click"],children:t.jsx(g.Z,{icon:S.Z,onClick:e=>{e.stopPropagation()},size:{blockSize:22,fontSize:16},style:{marginRight:-8}})})});var G=n(77621),C=n(31793);let F=(0,j.kc)(({css:e,prefixCls:o,token:n,responsive:t})=>({container:e`
    .${o}-collapse-header {
      padding-inline: 16px 10px !important;
      color: ${n.colorTextDescription} !important;
      border-radius: ${n.borderRadius}px !important;

      ${t.mobile} {
        border-radius: 0 !important;
      }

      &:hover {
        color: ${n.colorText} !important;
        background: ${n.colorFillTertiary};
        .${o}-collapse-extra {
          display: block;
        }
      }
    }
    .${o}-collapse-extra {
      display: none;
    }
    .${o}-collapse-content {
      border-radius: 0 !important;
    }
    .${o}-collapse-content-box {
      padding: 0 !important;
    }
  `,icon:e`
    transition: all 100ms ${n.motionEaseOut};
  `})),w=(0,i.memo)(e=>{let{styles:o}=F();return t.jsx(G.Z,{bordered:!1,className:o.container,expandIcon:({isActive:e})=>t.jsx(m.Z,{className:o.icon,icon:C.Z,size:{fontSize:16},style:e?{}:{rotate:"-90deg"}}),expandIconPosition:"end",ghost:!0,size:"small",...e})});var $=n(28253),z=n(46207),I=n(75175),P=n(41040),A=n(77072),N=n(42601),D=n(49370),M=n(67570);let{Item:B}=N.default,R=(0,j.kc)(({css:e,token:o,responsive:n})=>({container:e`
      position: relative;

      margin-block: 2px;
      padding-right: 16px;
      padding-left: 8px;

      border-radius: ${o.borderRadius}px;
      ${n.mobile} {
        margin-block: 0;
        padding-left: 12px;
        border-radius: 0;
      }
    `})),O=(0,i.memo)(({avatar:e,avatarBackground:o,active:n,showAction:s,actions:r,...a})=>{let l=(0,i.useRef)(null),c=(0,M.Z)(l),{mobile:p}=(0,$.F)(),{styles:d}=R(),u=(0,i.useMemo)(()=>t.jsx(D.Z,{animation:c,avatar:e,background:o,shape:"circle",size:46}),[c,e,o]);return t.jsx(B,{actions:r,active:!p&&n,avatar:u,className:d.container,ref:l,showAction:r&&(c||s),...a})}),T=(0,i.memo)(()=>{let{t:e}=(0,l.$G)("chat"),{mobile:o}=(0,$.F)(),[n,i]=(0,s.F)(e=>[e.activeId,e.switchSession]);return t.jsx(z.default,{"aria-label":e("inbox.title"),href:(0,A.gj)(P.B9,o),onClick:e=>{e.preventDefault(),i(P.B9)},children:t.jsx(O,{active:n===P.B9,avatar:I.Jo,title:e("inbox.title")})})});var E=n(45336),W=n(37854),K=n(88494);let L=(0,i.memo)(({groupId:e})=>{let{t:o}=(0,l.$G)("chat"),n=(0,s.F)(e=>e.createSession);return t.jsx(K.D,{style:{margin:"12px 16px"},children:t.jsx(W.ZP,{block:!0,icon:t.jsx(m.Z,{icon:f.Z}),onClick:()=>n({group:e}),children:o("newAgent")})})});var H=n(22602),Q=n(47897),J=n(90770),V=n(19031),X=n(95650),q=n(24130),U=n(13765),Y=n(81002);let _=(0,i.memo)(({id:e,open:o,onCancel:n})=>{let{t:r}=(0,l.$G)("chat"),a=(0,c.s)(e=>e.toggleExpandSessionGroup),{message:p}=x.Z.useApp(),[d,u]=(0,s.F)(e=>[e.updateSessionGroupId,e.addSessionGroup]),[m,g]=(0,i.useState)("");return t.jsx("div",{onClick:e=>e.stopPropagation(),children:t.jsx(U.Z,{allowFullscreen:!0,onCancel:n,onOk:async o=>{if(!m)return;if(0===m.length||m.length>20)return p.warning(r("sessionGroup.tooLong"));let t=await u(m);await d(e,t),a(t,!0),p.success(r("sessionGroup.createSuccess")),n?.(o)},open:o,title:r("sessionGroup.createGroup"),width:400,children:t.jsx(K.D,{paddingBlock:16,children:t.jsx(Y.I,{autoFocus:!0,onChange:e=>g(e.target.value),placeholder:r("sessionGroup.inputPlaceholder"),value:m})})})})});var ee=n(6023),eo=n(25049),en=n(80376),et=n(57552),ei=n(65894),es=n(32298),er=n(11271);let ea=e=>e.customSessionGroups.map(e=>({id:e.id,name:e.name})),el={getGroupById:e=>o=>ea(o).find(o=>o.id===e),sessionGroupItems:ea},ec=(0,j.kc)(({css:e})=>({modalRoot:e`
    z-index: 2000;
  `})),ep=(0,i.memo)(({group:e,id:o,openCreateGroupModal:n,setOpen:r})=>{let{styles:c}=ec(),{t:p}=(0,l.$G)("chat"),j=(0,s.F)(el.sessionGroupItems,a()),[k,Z,v,b,G]=(0,s.F)(e=>{let n=d.y.getSessionById(o)(e);return[X.k.getSessionPinned(n),e.removeSession,e.pinSession,e.duplicateSession,e.updateSessionGroupId]}),{modal:C}=x.Z.useApp(),F=e===u.z.Default,w=(0,i.useMemo)(()=>[{icon:t.jsx(m.Z,{icon:k?ee.Z:eo.Z}),key:"pin",label:p(k?"pinOff":"pin"),onClick:()=>{v(o,!k)}},{icon:t.jsx(m.Z,{icon:en.Z}),key:"duplicate",label:p("duplicate",{ns:"common"}),onClick:({domEvent:e})=>{e.stopPropagation(),b(o)}},{type:"divider"},{children:[...j.map(({id:n,name:i})=>({icon:e===n?t.jsx(m.Z,{icon:et.Z}):t.jsx("div",{}),key:n,label:i,onClick:()=>{G(o,n)}})),{icon:F?t.jsx(m.Z,{icon:et.Z}):t.jsx("div",{}),key:"defaultList",label:p("defaultList"),onClick:()=>{G(o,u.z.Default)}},{type:"divider"},{icon:t.jsx(m.Z,{icon:f.Z}),key:"createGroup",label:t.jsx("div",{children:p("sessionGroup.createGroup")}),onClick:({domEvent:e})=>{e.stopPropagation(),n()}}],icon:t.jsx(m.Z,{icon:ei.Z}),key:"moveGroup",label:p("sessionGroup.moveGroup")},{type:"divider"},{children:[{key:"agent",label:p("exportType.agent",{ns:"common"}),onClick:()=>{er.l.exportSingleAgent(o)}},{key:"agentWithMessage",label:p("exportType.agentWithMessage",{ns:"common"}),onClick:()=>{er.l.exportSingleSession(o)}}],icon:t.jsx(m.Z,{icon:es.Z}),key:"export",label:p("export",{ns:"common"})},{danger:!0,icon:t.jsx(m.Z,{icon:y.Z}),key:"delete",label:p("delete",{ns:"common"}),onClick:({domEvent:e})=>{e.stopPropagation(),C.confirm({centered:!0,okButtonProps:{danger:!0},onOk:()=>{Z(o)},rootClassName:c.modalRoot,title:p("confirmRemoveSessionItemAlert")})}}],[o,k]);return t.jsx(h.Z,{arrow:!1,menu:{items:w,onClick:({domEvent:e})=>{e.stopPropagation()}},onOpenChange:r,trigger:["click"],children:t.jsx(g.Z,{icon:S.Z,size:{blockSize:28,fontSize:16}})})}),ed=(0,i.memo)(({id:e})=>{let[o,n]=(0,i.useState)(!1),[r,a]=(0,i.useState)(!1),[l]=(0,c.s)(e=>[V.H.defaultAgentConfig(e).model]),[p]=(0,s.F)(o=>[o.activeId===e]),[u]=(0,J.a)(o=>[!!o.chatLoadingId&&e===o.activeId]),[m,g,x,h,j,k,f,Z,y]=(0,s.F)(o=>{let n=d.y.getSessionById(e)(o),t=n.meta,i=n.config.systemRole;return[X.k.getSessionPinned(n),q.y.getTitle(t),q.y.getDescription(t),i,q.y.getAvatar(t),t.backgroundColor,n?.updatedAt,n.config.model,n?.group]}),S=Z!==l,v=(0,i.useMemo)(()=>t.jsx(ep,{group:y,id:e,openCreateGroupModal:()=>a(!0),setOpen:n}),[y,e]),b=(0,i.useMemo)(()=>S?t.jsx(K.D,{gap:4,horizontal:!0,style:{flexWrap:"wrap"},children:S&&t.jsx(Q.Z,{model:Z})}):void 0,[S,Z]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(O,{actions:v,active:p,addon:b,avatar:j,avatarBackground:k,date:f,description:x||h,loading:u,pin:m,showAction:o,title:g}),t.jsx(_,{id:e,onCancel:()=>a(!1),open:r})]})},H.X);var eu=n(60718);let em=(0,j.kc)(({css:e})=>({avatar:e``,paragraph:e`
    height: 12px !important;
    margin-top: 12px !important;

    > li {
      height: 12px !important;
    }
  `,title:e`
    height: 14px !important;
    margin-top: 4px !important;
    margin-bottom: 12px !important;

    > li {
      height: 14px !important;
    }
  `})),eg=()=>{let{styles:e}=em(),o=Array.from({length:4}).fill("");return t.jsx(K.D,{gap:8,paddingInline:16,children:o.map((o,n)=>t.jsx(eu.Z,{active:!0,avatar:!0,paragraph:{className:e.paragraph,rows:1},title:{className:e.title}},n))})},ex=(0,j.kc)(({css:e})=>e`
    min-height: 70px;
  `),eh=(0,i.memo)(({dataSource:e,groupId:o,showAddButton:n=!0})=>{let[i,r,a]=(0,s.F)(e=>[e.activeSession,e.switchSession,d.y.isSessionListInit(e)]),{styles:l}=ex(),{mobile:c}=(0,$.F)();return a?e.length>0?e.map(({id:e})=>t.jsx(E.Z,{className:l,children:t.jsx(z.default,{"aria-label":e,href:(0,A.gj)(e,c),onClick:o=>{o.preventDefault(),c?r(e):i(e)},children:t.jsx(ed,{id:e})})},e)):n&&t.jsx(L,{groupId:o}):t.jsx(eg,{})});var ej=n(63792),ek=n(67263),ef=n(35722);let eZ=(0,j.kc)(({css:e})=>({content:e`
    position: relative;
    overflow: hidden;
    flex: 1;
  `,title:e`
    flex: 1;
    height: 28px;
    line-height: 28px;
    text-align: start;
  `})),ey=(0,i.memo)(({id:e,name:o})=>{let{t:n}=(0,l.$G)("chat"),{styles:r}=eZ(),{message:a}=x.Z.useApp(),[c,p]=(0,i.useState)(!1),[d,u]=(0,s.F)(e=>[e.updateSessionGroupName,e.removeSessionGroup]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(ej.Z.DragHandle,{}),c?t.jsx(ek.Z,{editing:c,onChangeEnd:t=>{if(o!==t){if(!t)return;if(0===t.length||t.length>20)return a.warning(n("sessionGroup.tooLong"));d(e,t),a.success(n("sessionGroup.renameSuccess"))}p(!1)},onEditingChange:e=>p(e),showEditIcon:!1,size:"small",style:{height:28},type:"pure",value:o}):(0,t.jsxs)(t.Fragment,{children:[t.jsx("span",{className:r.title,children:o}),t.jsx(g.Z,{icon:Z.Z,onClick:()=>p(!0),size:"small"}),t.jsx(ef.Z,{arrow:!1,okButtonProps:{danger:!0,type:"primary"},onConfirm:()=>{u(e)},title:n("sessionGroup.confirmRemoveGroupAlert"),children:t.jsx(g.Z,{icon:y.Z,size:"small"})})]})]})}),eS=(0,j.kc)(({css:e,token:o,stylish:n})=>({container:e`
    height: 36px;
    padding-inline: 8px;
    border-radius: ${o.borderRadius}px;
    transition: background 0.2s ease-in-out;

    &:hover {
      ${n.blur};
      background: ${o.colorFillTertiary};
    }
  `})),ev=(0,i.memo)(({open:e,onCancel:o})=>{let{t:n}=(0,l.$G)("chat"),{styles:i}=eS(),r=(0,s.F)(el.sessionGroupItems,a()),[c,p]=(0,s.F)(e=>[e.addSessionGroup,e.updateSessionGroupSort]);return t.jsx(U.Z,{allowFullscreen:!0,footer:null,onCancel:o,open:e,title:n("sessionGroup.config"),width:400,children:(0,t.jsxs)(K.D,{children:[t.jsx(ej.Z,{items:r,onChange:e=>{p(e)},renderItem:e=>t.jsx(ej.Z.Item,{align:"center",className:i.container,gap:4,horizontal:!0,id:e.id,justify:"space-between",children:t.jsx(ey,{...e})})}),t.jsx(W.ZP,{block:!0,icon:t.jsx(m.Z,{icon:f.Z}),onClick:()=>c(n("sessionGroup.newGroup")),children:n("sessionGroup.createGroup")})]})})}),eb=(0,i.memo)(({id:e,open:o,onCancel:n})=>{let{t:r}=(0,l.$G)("chat"),c=(0,s.F)(e=>e.updateSessionGroupName),p=(0,s.F)(o=>el.getGroupById(e)(o),a()),[d,u]=(0,i.useState)(),{message:m}=x.Z.useApp();return t.jsx(U.Z,{allowFullscreen:!0,onCancel:n,onOk:o=>{if(d){if(0===d.length||d.length>20)return m.warning(r("sessionGroup.tooLong"));c(e,d),m.success(r("sessionGroup.renameSuccess")),n?.(o)}},open:o,title:r("sessionGroup.rename"),width:400,children:t.jsx(Y.I,{autoFocus:!0,defaultValue:p?.name,onChange:e=>u(e.target.value),placeholder:r("sessionGroup.inputPlaceholder"),value:d})})}),eG=(0,i.memo)(()=>{let{t:e}=(0,l.$G)("chat"),[o,n]=(0,i.useState)(),[r,m]=(0,i.useState)(!1),[g,x]=(0,i.useState)(!1),[h]=(0,s.F)(e=>[e.useFetchSessions]);h();let j=(0,s.F)(d.y.pinnedSessions,a()),k=(0,s.F)(d.y.defaultSessions,a()),f=(0,s.F)(d.y.customSessionGroups,a()),[Z,y]=(0,c.s)(e=>[p.l.sessionGroupKeys(e),e.updatePreference]),S=(0,i.useMemo)(()=>[j.length>0&&{children:t.jsx(eh,{dataSource:j}),extra:t.jsx(b,{isPinned:!0,openConfigModal:()=>x(!0)}),key:u.z.Pinned,label:e("pin")},...f.map(({id:e,name:o,children:i})=>({children:t.jsx(eh,{dataSource:i,groupId:e}),extra:t.jsx(b,{id:e,isCustomGroup:!0,onOpenChange:o=>{o&&n(e)},openConfigModal:()=>x(!0),openRenameModal:()=>m(!0)}),key:e,label:o})),{children:t.jsx(eh,{dataSource:k}),extra:t.jsx(b,{openConfigModal:()=>x(!0)}),key:u.z.Default,label:e("defaultList")}].filter(Boolean),[f,j,k]);return(0,t.jsxs)(t.Fragment,{children:[t.jsx(T,{}),t.jsx(w,{activeKey:Z,items:S,onChange:e=>{y({expandSessionGroupKeys:"string"==typeof e?[e]:e})}}),o&&t.jsx(eb,{id:o,onCancel:()=>m(!1),open:r}),t.jsx(ev,{onCancel:()=>x(!1),open:g})]})}),eC=(0,i.memo)(()=>{let e=(0,s.F)(d.y.searchSessions,a());return t.jsx(eh,{dataSource:e,showAddButton:!1})}),eF=(0,i.memo)(()=>(0,s.F)(e=>e.isSearching)?t.jsx(eC,{}):t.jsx(eG,{}))},4337:(e,o,n)=>{n.d(o,{Z:()=>c});var t=n(88178),i=n(80497),s=n(28253),r=n(61026),a=n(38570),l=n(47234);let c=(0,r.memo)(()=>{let{t:e}=(0,a.$G)("chat"),[o,n]=(0,r.useState)(void 0),[c]=(0,l.F)(e=>[e.useSearchSessions]);c(o);let{mobile:p}=(0,s.F)();return t.jsx(i.Z,{allowClear:!0,enableShortKey:!p,onChange:e=>{let o=e.target.value;n(o),l.F.setState({isSearching:!!o})},placeholder:e("searchAgentPlaceholder"),shortKey:"k",spotlight:!p,type:p?"block":"ghost",value:o})})},48850:(e,o,n)=>{n.d(o,{Z:()=>l});var t=n(88178),i=n(61026),s=n(38570),r=n(46627),a=n(61420);let l=({children:e,Mobile:o})=>{let{t:n}=(0,s.$G)();return(0,a.d)()?t.jsx(i.Suspense,{fallback:t.jsx(r.Z,{title:n("layoutInitializing",{ns:"common"})}),children:t.jsx(o,{})}):e}},41299:(e,o,n)=>{n.d(o,{l:()=>t});let t={sessionGroupKeys:e=>e.preference.expandSessionGroupKeys||[],useCmdEnterToSend:e=>e.preference.useCmdEnterToSend||!1}}};