"use strict";exports.id=44412,exports.ids=[44412],exports.modules={44412:(t,e,o)=>{o.r(e),o.d(e,{default:()=>Z});var a=o(88178),n=o(47312),i=o(287),s=o(49342),r=o(20551),l=o(20426),c=o(61026),d=o(60634),p=o(88494),m=o(24867),g=o(68335),h=o(49773),x=o(47234),u=o(60496),v=o(24130),y=o(60660),j=o(6488);let k=(0,o(76054).kc)(({css:t,token:e})=>({prompt:t`
    overflow: hidden auto;
    padding: 0 16px 16px;
    opacity: 0.75;
    transition: opacity 200ms ${e.motionEaseOut};

    &:hover {
      opacity: 1;
    }
  `,promptBox:t`
    position: relative;
    overflow: hidden;
    border-bottom: 1px solid ${e.colorBorder};
  `,promptMask:t`
    pointer-events: none;

    position: absolute;
    z-index: 10;
    bottom: 0;
    left: 0;

    width: 100%;
    height: 32px;

    background: linear-gradient(to bottom, transparent, ${e.colorBgLayout});
  `})),Z=(0,c.memo)(()=>{let t=(0,l.useRouter)(),[e,o]=(0,c.useState)(!1),{styles:Z}=k(),[f,C,w,b]=(0,x.F)(t=>[u.y.isSomeSessionActive(t),v.y.currentAgentSystemRole(t),v.y.currentAgentMeta(t),t.updateAgentConfig]),[A,N]=(0,h.s)(t=>[t.preference.showSystemRole,t.toggleSystemRole]),[S,$]=(0,m.Z)(!1,{defaultValue:A,onChange:N,value:A}),{t:z}=(0,d.$G)("common"),B=()=>{f&&(o(!0),$(!0))};return(0,a.jsxs)(p.D,{height:"fit-content",children:[a.jsx(j.Z,{actions:a.jsx(n.Z,{icon:r.Z,onClick:B,size:"small",title:z("edit")}),title:z("settingAgent.prompt.title",{ns:"setting"})}),a.jsx(p.D,{className:Z.promptBox,height:200,onClick:()=>{f&&$(!0)},onDoubleClick:t=>{t.altKey&&B()},children:f?(0,a.jsxs)(a.Fragment,{children:[a.jsx(i.Z,{classNames:{markdown:Z.prompt},editing:e,model:{extra:a.jsx(g.Z,{meta:w,onAvatarClick:()=>{$(!1),o(!1),t.push((0,y.H)("/chat/settings",{hash:location.hash}))},style:{marginBottom:16}})},onChange:t=>{b({systemRole:t})},onEditingChange:o,onOpenChange:$,openModal:S,placeholder:`${z("settingAgent.prompt.placeholder",{ns:"setting"})}...`,styles:{markdown:C?{}:{opacity:.5}},text:{cancel:z("cancel"),confirm:z("ok"),edit:z("edit"),title:z("settingAgent.prompt.title",{ns:"setting"})},value:C}),a.jsx("div",{className:Z.promptMask})]}):a.jsx(s.Z,{active:!0,avatar:!1,style:{marginTop:12,paddingInline:16},title:!1})})]})})},68335:(t,e,o)=>{o.d(e,{Z:()=>g});var a=o(88178),n=o(27225),i=o(5098),s=o(33876),r=o(1212),l=o(76054),c=o(10926),d=o(61026),p=o(45403);let m=(0,l.kc)(({css:t,token:e,stylish:o})=>({avatar:t`
    flex: none;
  `,desc:t`
    color: ${e.colorTextDescription};
    text-align: center;
  `,markdown:o.markdownInChat,title:t`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),g=(0,d.memo)(({systemRole:t,style:e,meta:o,onAvatarClick:l})=>{let{styles:d,theme:g}=m();if(o)return(0,a.jsxs)(p.Z,{gap:16,style:e,children:[o.avatar&&a.jsx(n.Z,{animation:!0,avatar:o.avatar,background:o.backgroundColor||g.colorFillTertiary,className:d.avatar,onClick:l,size:100}),o.title&&a.jsx("div",{className:d.title,children:o.title}),o?.tags?.length>0&&a.jsx(p.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:o.tags.map((t,e)=>a.jsx(i.Z,{style:{margin:0},children:(0,c.Z)(t).trim()},e))}),o.description&&a.jsx("div",{className:d.desc,children:o.description}),t&&(0,a.jsxs)(a.Fragment,{children:[a.jsx(r.Z,{style:{margin:"8px 0"}}),a.jsx(s.Z,{className:d.markdown,children:t})]})]})})}};