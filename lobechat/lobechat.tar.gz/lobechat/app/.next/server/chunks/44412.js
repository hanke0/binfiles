"use strict";exports.id=44412,exports.ids=[44412],exports.modules={44412:(e,t,o)=>{o.r(t),o.d(t,{default:()=>Z});var a=o(88178),n=o(64108),i=o(1088),s=o(60718),r=o(11105),l=o(20426),c=o(61026),d=o(38570),p=o(88494),m=o(24867),g=o(68335),x=o(49773),h=o(47234),u=o(60496),v=o(24130),y=o(60660),j=o(6488);let k=(0,o(36315).kc)(({css:e,token:t})=>({prompt:e`
    overflow: hidden auto;
    padding: 0 16px 16px;
    opacity: 0.75;
    transition: opacity 200ms ${t.motionEaseOut};

    &:hover {
      opacity: 1;
    }
  `,promptBox:e`
    position: relative;
    overflow: hidden;
    border-bottom: 1px solid ${t.colorBorder};
  `,promptMask:e`
    pointer-events: none;

    position: absolute;
    z-index: 10;
    bottom: 0;
    left: 0;

    width: 100%;
    height: 32px;

    background: linear-gradient(to bottom, transparent, ${t.colorBgLayout});
  `})),Z=(0,c.memo)(()=>{let e=(0,l.useRouter)(),[t,o]=(0,c.useState)(!1),{styles:Z}=k(),[f,C,w,b]=(0,h.F)(e=>[u.y.isSomeSessionActive(e),v.y.currentAgentSystemRole(e),v.y.currentAgentMeta(e),e.updateAgentConfig]),[A,N]=(0,x.s)(e=>[e.preference.showSystemRole,e.toggleSystemRole]),[S,$]=(0,m.Z)(!1,{defaultValue:A,onChange:N,value:A}),{t:z}=(0,d.$G)("common"),B=()=>{f&&(o(!0),$(!0))};return(0,a.jsxs)(p.D,{height:"fit-content",children:[a.jsx(j.Z,{actions:a.jsx(n.Z,{icon:r.Z,onClick:B,size:"small",title:z("edit")}),title:z("settingAgent.prompt.title",{ns:"setting"})}),a.jsx(p.D,{className:Z.promptBox,height:200,onClick:()=>{f&&$(!0)},onDoubleClick:e=>{e.altKey&&B()},children:f?(0,a.jsxs)(a.Fragment,{children:[a.jsx(i.Z,{classNames:{markdown:Z.prompt},editing:t,model:{extra:a.jsx(g.Z,{meta:w,onAvatarClick:()=>{$(!1),o(!1),e.push((0,y.H)("/chat/settings",{search:location.search}))},style:{marginBottom:16}})},onChange:e=>{b({systemRole:e})},onEditingChange:o,onOpenChange:$,openModal:S,placeholder:`${z("settingAgent.prompt.placeholder",{ns:"setting"})}...`,styles:{markdown:C?{}:{opacity:.5}},text:{cancel:z("cancel"),confirm:z("ok"),edit:z("edit"),title:z("settingAgent.prompt.title",{ns:"setting"})},value:C}),a.jsx("div",{className:Z.promptMask})]}):a.jsx(s.Z,{active:!0,avatar:!1,style:{marginTop:12,paddingInline:16},title:!1})})]})})},68335:(e,t,o)=>{o.d(t,{Z:()=>g});var a=o(88178),n=o(49370),i=o(62979),s=o(2647),r=o(8301),l=o(36315),c=o(10926),d=o(61026),p=o(45403);let m=(0,l.kc)(({css:e,token:t,stylish:o})=>({avatar:e`
    flex: none;
  `,desc:e`
    color: ${t.colorTextDescription};
    text-align: center;
  `,markdown:o.markdownInChat,title:e`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),g=(0,d.memo)(({systemRole:e,style:t,meta:o,onAvatarClick:l})=>{let{styles:d,theme:g}=m();if(o)return(0,a.jsxs)(p.Z,{gap:16,style:t,children:[o.avatar&&a.jsx(n.Z,{animation:!0,avatar:o.avatar,background:o.backgroundColor||g.colorFillTertiary,className:d.avatar,onClick:l,size:100}),o.title&&a.jsx("div",{className:d.title,children:o.title}),o?.tags?.length>0&&a.jsx(p.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:o.tags.map((e,t)=>a.jsx(i.Z,{style:{margin:0},children:(0,c.Z)(e).trim()},t))}),o.description&&a.jsx("div",{className:d.desc,children:o.description}),e&&(0,a.jsxs)(a.Fragment,{children:[a.jsx(r.Z,{style:{margin:"8px 0"}}),a.jsx(s.Z,{className:d.markdown,children:e})]})]})})}};