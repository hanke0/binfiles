"use strict";exports.id=53206,exports.ids=[53206],exports.modules={53206:(e,t,a)=>{a.r(t),a.d(t,{default:()=>g});var r=a(88178),n=a(92369),l=a(33634),s=a(441),i=a(36315),o=a(61026),c=a(43094),d=a(48864),m=a(79221),x=a(23990),p=a(81882);let h=(0,i.kc)(({css:e,token:t,stylish:a})=>({content:e`
    display: flex;
    flex-direction: column;
    height: 100% !important;
  `,drawer:e`
    background: ${t.colorBgLayout};
  `,header:e`
    border-bottom: 1px solid ${t.colorBorder};
  `,noScrollbar:a.noScrollbar})),g=(0,o.memo)(()=>{let{styles:e}=h(),[t,a]=(0,o.useState)(""),[i,g,u]=(0,m.F)(e=>[x._.showSideBar(e),e.deactivateAgent,e.activateAgent]),j=(0,o.useCallback)(e=>{e?t&&u(t):(a(m.F.getState().currentIdentifier),g())},[g,u,t]);return r.jsx(n.Z,{className:e.drawer,classNames:{content:e.content},expand:i,minWidth:d.hc,mode:"fixed",onExpandChange:j,placement:"right",children:(0,r.jsxs)(l.Z,{style:{flex:"none",height:"100%",minWidth:d.hc},children:[r.jsx(c.Z,{}),r.jsx(s.Z,{className:e.noScrollbar,style:{padding:0,position:"relative"},children:r.jsx(p.Z,{})})]})})})},81882:(e,t,a)=>{a.d(t,{Z:()=>$});var r,n=a(88178),l=a(61026),s=a(88494),i=a(61885),o=a(2647),c=a(38570),d=a(79221),m=a(73228),x=a(98606);let p=(0,l.memo)(({identifier:e})=>n.jsx(x.Z,{category:"General",categoryId:"DIC_kwDOKON5YM4CZNRJ",id:"lobehub",mapping:"specific",repo:"lobehub/lobe-chat-agents",repoId:"R_kgDOKON5YA",term:e}));var h=a(49370),g=a(62979),u=a(76701),j=a(66679),v=a(37854),f=a(10926),Z=a(45403),y=a(23990),b=a(47234),k=a(36315);let N=(0,k.kc)(({css:e,token:t,prefixCls:a,stylish:r})=>({author:e`
    font-size: 12px;
  `,avatar:e`
    flex: none;
  `,container:e`
    position: relative;
    padding: 16px 16px 24px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
  `,date:e`
    font-size: 12px;
    color: ${t.colorTextDescription};
  `,desc:e`
    color: ${t.colorTextDescription};
    text-align: center;
  `,loading:e`
    .${a}-skeleton-content {
      display: flex;
      flex-direction: column;
    }
  `,markdown:r.markdownInChat,nav:e`
    padding-top: 8px;
  `,title:e`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),{Link:w}=u.default,B=(0,l.memo)(()=>{let{t:e}=(0,c.$G)("market"),{styles:t,theme:a}=N(),r=(0,b.F)(e=>e.createSession),l=(0,d.F)(y._.currentAgentItem),{message:s}=j.Z.useApp(),{meta:i,createAt:o,author:m,homepage:x,config:p}=l,{avatar:u,title:k,description:B,tags:S,backgroundColor:z}=i;return(0,n.jsxs)(Z.Z,{className:t.container,gap:16,children:[n.jsx(h.Z,{animation:!0,avatar:u,background:z||a.colorFillTertiary,className:t.avatar,size:100}),n.jsx("div",{className:t.title,children:k}),n.jsx(Z.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:S.map((e,t)=>n.jsx(g.Z,{onClick:()=>d.F.setState({searchKeywords:e}),style:{margin:0},children:(0,f.Z)(e).trim()},t))}),n.jsx("div",{className:t.desc,children:B}),(0,n.jsxs)(w,{"aria-label":m,className:t.author,href:x,target:"_blank",children:["@",m]}),n.jsx(v.ZP,{block:!0,onClick:()=>{l&&r({config:p,meta:i})},type:"primary",children:e("addAgentAndConverse")}),n.jsx(v.ZP,{block:!0,onClick:()=>{l&&(r({config:p,meta:i},!1),s.success(e("addAgentSuccess")))},children:e("addAgent")}),n.jsx("div",{className:t.date,children:o})]})});var S=a(60718);let z=(0,l.memo)(()=>{let{styles:e}=N();return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(Z.Z,{className:e.container,gap:16,style:{paddingTop:80},children:[n.jsx(S.Z.Avatar,{active:!0,shape:"circle",size:100}),n.jsx(S.Z,{active:!0,className:e.loading,paragraph:{rows:3,style:{alignItems:"center",display:"flex",flexDirection:"column"},width:["60%","80%","20%"]},title:{style:{alignSelf:"center",marginBottom:0},width:"50%"}}),n.jsx(S.Z.Button,{active:!0,block:!0}),n.jsx(S.Z.Button,{active:!0,block:!0}),n.jsx(S.Z,{active:!0,className:e.loading,paragraph:{rows:1,style:{alignItems:"center",display:"flex",flexDirection:"column",marginBottom:0},width:["20%"]},title:!1})]}),(0,n.jsxs)(Z.Z,{gap:16,style:{padding:16},children:[(0,n.jsxs)(s.D,{gap:16,horizontal:!0,children:[n.jsx(S.Z.Button,{active:!0,size:"small"}),n.jsx(S.Z.Button,{active:!0,size:"small"})]}),n.jsx(S.Z,{active:!0,paragraph:{rows:6},title:!1})]})]})});var D=a(75367);let A=(0,k.kc)(({css:e,token:t})=>e`
    padding: 2px 5px;

    font-size: 12px;
    line-height: 1;
    color: ${t.colorBgLayout};

    background: ${t.colorText};
    border-radius: 12px;
  `),C=(0,l.memo)(({systemRole:e})=>{let{styles:t}=A(),a=(0,D.e)(e);return n.jsx("div",{className:t,children:a})});!function(e){e.comment="comment",e.prompt="prompt"}(r||(r={}));let F=(0,l.memo)(()=>{let[e,t]=(0,d.F)(e=>[e.useFetchAgent,e.currentIdentifier]),{t:a}=(0,c.$G)("market"),[r,x]=(0,l.useState)("prompt"),{data:h,isLoading:g}=e(t),{styles:u}=N();if(g||!h?.meta)return n.jsx(z,{});let{config:j,meta:v,identifier:f}=h,{systemRole:Z}=j;return(0,n.jsxs)(n.Fragment,{children:[n.jsx(m.Z,{meta:v,size:400,style:{height:120,marginBottom:-60}}),n.jsx(B,{}),n.jsx(s.D,{align:"center",children:n.jsx(i.Z,{activeKey:r,className:u.nav,items:[{key:"prompt",label:(0,n.jsxs)(s.D,{align:"center",gap:8,horizontal:!0,children:[a("sidebar.prompt")," ",n.jsx(C,{systemRole:Z})]})},{key:"comment",label:a("sidebar.comment")}],onChange:x,variant:"compact"})}),(0,n.jsxs)(s.D,{style:{padding:16},children:["prompt"===r&&n.jsx(o.Z,{className:u.markdown,fullFeaturedCodeBlock:!0,children:Z}),"comment"===r&&n.jsx(p,{identifier:f})]})]})}),$=(0,l.memo)(()=>n.jsx(s.D,{children:n.jsx(F,{})}))},75367:(e,t,a)=>{a.d(t,{e:()=>l});var r=a(61026),n=a(38952);let l=(e="")=>{let[t,a]=(0,r.useState)(0);return(0,r.useEffect)(()=>{(0,r.startTransition)(()=>{(0,n.W)(e).then(a).catch(()=>{a(e.length)})})},[e]),t}}};