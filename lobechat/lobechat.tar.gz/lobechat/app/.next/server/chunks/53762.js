"use strict";exports.id=53762,exports.ids=[53762],exports.modules={22305:(e,t,a)=>{a.d(t,{Z:()=>r});/**
 * @license lucide-react v0.321.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(11112).Z)("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]])},53206:(e,t,a)=>{a.r(t),a.d(t,{default:()=>g});var r=a(88178),n=a(40167),s=a(76243),l=a(76927),i=a(76054),o=a(61026),c=a(43094),d=a(48864),m=a(79221),p=a(23990),x=a(81882);let h=(0,i.kc)(({css:e,token:t,stylish:a})=>({content:e`
    display: flex;
    flex-direction: column;
    height: 100% !important;
  `,drawer:e`
    background: ${t.colorBgLayout};
  `,header:e`
    border-bottom: 1px solid ${t.colorBorder};
  `,noScrollbar:a.noScrollbar})),g=(0,o.memo)(()=>{let{styles:e}=h(),[t,a]=(0,o.useState)(""),[i,g,u]=(0,m.F)(e=>[p._.showSideBar(e),e.deactivateAgent,e.activateAgent]),j=(0,o.useCallback)(e=>{e?t&&u(t):(a(m.F.getState().currentIdentifier),g())},[g,u,t]);return r.jsx(n.Z,{className:e.drawer,classNames:{content:e.content},expand:i,minWidth:d.hc,mode:"fixed",onExpandChange:j,placement:"right",children:(0,r.jsxs)(s.Z,{style:{flex:"none",height:"100%",minWidth:d.hc},children:[r.jsx(c.Z,{}),r.jsx(l.Z,{className:e.noScrollbar,style:{padding:0,position:"relative"},children:r.jsx(x.Z,{})})]})})})},81882:(e,t,a)=>{a.d(t,{Z:()=>T});var r,n=a(88178),s=a(61026),l=a(88494),i=a(77069),o=a(33876),c=a(60634),d=a(79221),m=a(73228),p=a(70285);let x=(0,s.memo)(({identifier:e})=>n.jsx(p.Z,{category:"General",categoryId:"DIC_kwDOKON5YM4CZNRJ",id:"lobehub",mapping:"specific",repo:"lobehub/lobe-chat-agents",repoId:"R_kgDOKON5YA",term:e}));var h=a(27225),g=a(5098),u=a(3117),j=a(35123),v=a(42130),Z=a(10926),f=a(45403),y=a(49773),b=a(17348),k=a(23990),N=a(47234),w=a(76054);let B=(0,w.kc)(({css:e,token:t,prefixCls:a,stylish:r})=>({author:e`
    font-size: 12px;
  `,avatar:e`
    flex: none;
  `,container:e`
    position: relative;
    padding: 16px 16px 24px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
  `,date:e`
    font-size: 12px;
    color: ${t.colorTextDescription};
  `,desc:e`
    color: ${t.colorTextDescription};
    text-align: center;
  `,loading:e`
    .${a}-skeleton-content {
      display: flex;
      flex-direction: column;
    }
  `,markdown:r.markdownInChat,nav:e`
    padding-top: 8px;
  `,title:e`
    font-size: 20px;
    font-weight: 600;
    text-align: center;
  `})),{Link:S}=u.default,z=(0,s.memo)(()=>{let{t:e}=(0,c.$G)("market"),{styles:t,theme:a}=B(),r=(0,N.F)(e=>e.createSession),s=(0,y.s)(e=>e.switchSideBar),l=(0,d.F)(k._.currentAgentItem),{message:i}=j.Z.useApp(),{meta:o,createAt:m,author:p,homepage:x,config:u}=l,{avatar:w,title:z,description:C,tags:D,backgroundColor:A}=o;return(0,n.jsxs)(f.Z,{className:t.container,gap:16,children:[n.jsx(h.Z,{animation:!0,avatar:w,background:A||a.colorFillTertiary,className:t.avatar,size:100}),n.jsx("div",{className:t.title,children:z}),n.jsx(f.Z,{gap:6,horizontal:!0,style:{flexWrap:"wrap"},children:D.map((e,t)=>n.jsx(g.Z,{onClick:()=>d.F.setState({searchKeywords:e}),style:{margin:0},children:(0,Z.Z)(e).trim()},t))}),n.jsx("div",{className:t.desc,children:C}),(0,n.jsxs)(S,{"aria-label":p,className:t.author,href:x,target:"_blank",children:["@",p]}),n.jsx(v.ZP,{block:!0,onClick:()=>{l&&(r({config:u,meta:o}),s(b.i6.Chat))},type:"primary",children:e("addAgentAndConverse")}),n.jsx(v.ZP,{block:!0,onClick:()=>{l&&(r({config:u,meta:o},!1),i.success(e("addAgentSuccess")))},children:e("addAgent")}),n.jsx("div",{className:t.date,children:m})]})});var C=a(49342);let D=(0,s.memo)(()=>{let{styles:e}=B();return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(f.Z,{className:e.container,gap:16,style:{paddingTop:80},children:[n.jsx(C.Z.Avatar,{active:!0,shape:"circle",size:100}),n.jsx(C.Z,{active:!0,className:e.loading,paragraph:{rows:3,style:{alignItems:"center",display:"flex",flexDirection:"column"},width:["60%","80%","20%"]},title:{style:{alignSelf:"center",marginBottom:0},width:"50%"}}),n.jsx(C.Z.Button,{active:!0,block:!0}),n.jsx(C.Z.Button,{active:!0,block:!0}),n.jsx(C.Z,{active:!0,className:e.loading,paragraph:{rows:1,style:{alignItems:"center",display:"flex",flexDirection:"column",marginBottom:0},width:["20%"]},title:!1})]}),(0,n.jsxs)(f.Z,{gap:16,style:{padding:16},children:[(0,n.jsxs)(l.D,{gap:16,horizontal:!0,children:[n.jsx(C.Z.Button,{active:!0,size:"small"}),n.jsx(C.Z.Button,{active:!0,size:"small"})]}),n.jsx(C.Z,{active:!0,paragraph:{rows:6},title:!1})]})]})});var A=a(75367);let F=(0,w.kc)(({css:e,token:t})=>e`
    padding: 2px 5px;

    font-size: 12px;
    line-height: 1;
    color: ${t.colorBgLayout};

    background: ${t.colorText};
    border-radius: 12px;
  `),$=(0,s.memo)(({systemRole:e})=>{let{styles:t}=F(),a=(0,A.e)(e);return n.jsx("div",{className:t,children:a})});!function(e){e.comment="comment",e.prompt="prompt"}(r||(r={}));let I=(0,s.memo)(()=>{let[e,t]=(0,d.F)(e=>[e.useFetchAgent,e.currentIdentifier]),{t:a}=(0,c.$G)("market"),[r,p]=(0,s.useState)("prompt"),{data:h,isLoading:g}=e(t),{styles:u}=B();if(g||!h?.meta)return n.jsx(D,{});let{config:j,meta:v,identifier:Z}=h,{systemRole:f}=j;return(0,n.jsxs)(n.Fragment,{children:[n.jsx(m.Z,{meta:v,size:400,style:{height:120,marginBottom:-60}}),n.jsx(z,{}),n.jsx(l.D,{align:"center",children:n.jsx(i.Z,{activeKey:r,className:u.nav,items:[{key:"prompt",label:(0,n.jsxs)(l.D,{align:"center",gap:8,horizontal:!0,children:[a("sidebar.prompt")," ",n.jsx($,{systemRole:f})]})},{key:"comment",label:a("sidebar.comment")}],onChange:p,variant:"compact"})}),(0,n.jsxs)(l.D,{style:{padding:16},children:["prompt"===r&&n.jsx(o.Z,{className:u.markdown,fullFeaturedCodeBlock:!0,children:f}),"comment"===r&&n.jsx(x,{identifier:Z})]})]})}),T=(0,s.memo)(()=>n.jsx(l.D,{children:n.jsx(I,{})}))},75367:(e,t,a)=>{a.d(t,{e:()=>s});var r=a(61026),n=a(38952);let s=(e="")=>{let[t,a]=(0,r.useState)(0);return(0,r.useEffect)(()=>{(0,r.startTransition)(()=>{(0,n.W)(e).then(a).catch(()=>{a(e.length)})})},[e]),t}}};