#!/usr/bin/env bash
set -e
node server.js
