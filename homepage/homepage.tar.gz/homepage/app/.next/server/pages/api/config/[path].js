"use strict";
(() => {
var exports = {};
exports.id = 390;
exports.ids = [390];
exports.modules = {

/***/ 2108:
/***/ ((module) => {

module.exports = require("memory-cache");

/***/ }),

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 7261:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 360:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4574);
/* harmony import */ var utils_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3036);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_config_config__WEBPACK_IMPORTED_MODULE_2__, utils_logger__WEBPACK_IMPORTED_MODULE_3__]);
([utils_config_config__WEBPACK_IMPORTED_MODULE_2__, utils_logger__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const logger = (0,utils_logger__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)("configFileService");
/**
 * @param {import("next").NextApiRequest} req
 * @param {import("next").NextApiResponse} res
 */

async function handler(req, res) {
  const {
    path: relativePath
  } = req.query; // only two supported files, for now

  if (!["custom.css", "custom.js"].includes(relativePath)) {
    return res.status(422).end("Unsupported file");
  }

  const filePath = path__WEBPACK_IMPORTED_MODULE_0___default().join(utils_config_config__WEBPACK_IMPORTED_MODULE_2__/* .CONF_DIR */ .Fn, relativePath);

  try {
    // Read the content of the file or return empty content
    const fileContent = fs__WEBPACK_IMPORTED_MODULE_1___default().existsSync(filePath) ? fs__WEBPACK_IMPORTED_MODULE_1___default().readFileSync(filePath, "utf-8") : ""; // hard-coded since we only support two known files for now

    const mimeType = relativePath === "custom.css" ? "text/css" : "text/javascript";
    res.setHeader("Content-Type", mimeType);
    return res.status(200).send(fileContent);
  } catch (error) {
    logger.error(error);
    return res.status(500).end("Internal Server Error");
  }
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4574,3036], () => (__webpack_exec__(360)));
module.exports = __webpack_exports__;

})();