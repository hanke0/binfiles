"use strict";
(() => {
var exports = {};
exports.id = 7682;
exports.ids = [7682];
exports.modules = {

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 2108:
/***/ ((module) => {

module.exports = require("memory-cache");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 764:
/***/ ((module) => {

module.exports = require("react-icons/si");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 7552:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vD": () => (/* binding */ searchProviders)
/* harmony export */ });
/* unused harmony exports getStoredProvider, default */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(764);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_si__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1185);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _widget_container_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5049);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_4__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const searchProviders = {
  google: {
    name: "Google",
    url: "https://www.google.com/search?q=",
    suggestionUrl: "https://www.google.com/complete/search?client=chrome&q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiGoogle
  },
  duckduckgo: {
    name: "DuckDuckGo",
    url: "https://duckduckgo.com/?q=",
    suggestionUrl: "https://duckduckgo.com/ac/?type=list&q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiDuckduckgo
  },
  bing: {
    name: "Bing",
    url: "https://www.bing.com/search?q=",
    suggestionUrl: "https://api.bing.com/osjson.aspx?query=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiMicrosoftbing
  },
  baidu: {
    name: "Baidu",
    url: "https://www.baidu.com/s?wd=",
    suggestionUrl: "http://suggestion.baidu.com/su?&action=opensearch&ie=utf-8&wd=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiBaidu
  },
  brave: {
    name: "Brave",
    url: "https://search.brave.com/search?q=",
    suggestionUrl: "https://search.brave.com/api/suggest?&rich=false&q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiBrave
  },
  custom: {
    name: "Custom",
    url: false,
    icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiSearch
  }
};

function getAvailableProviderIds(options) {
  if (options.provider && Array.isArray(options.provider)) {
    return Object.keys(searchProviders).filter(value => options.provider.includes(value));
  }

  if (options.provider && searchProviders[options.provider]) {
    return [options.provider];
  }

  return null;
}

const localStorageKey = "search-name";
function getStoredProvider() {
  if (false) {}

  return null;
}
function Search({
  options
}) {
  const {
    t
  } = useTranslation();
  const availableProviderIds = getAvailableProviderIds(options);
  const {
    0: query,
    1: setQuery
  } = useState("");
  const {
    0: selectedProvider,
    1: setSelectedProvider
  } = useState(searchProviders[availableProviderIds[0] ?? searchProviders.google]);
  const {
    0: searchSuggestions,
    1: setSearchSuggestions
  } = useState([]);
  useEffect(() => {
    const storedProvider = getStoredProvider();
    let storedProviderKey = null;
    storedProviderKey = Object.keys(searchProviders).find(pkey => searchProviders[pkey] === storedProvider);

    if (storedProvider && availableProviderIds.includes(storedProviderKey)) {
      setSelectedProvider(storedProvider);
    }
  }, [availableProviderIds]);
  useEffect(() => {
    const abortController = new AbortController();

    if (options.showSearchSuggestions && (selectedProvider.suggestionUrl || options.suggestionUrl) && // custom providers pass url via options
    query.trim() !== searchSuggestions[0]) {
      fetch(`/api/search/searchSuggestion?query=${encodeURIComponent(query)}&providerName=${selectedProvider.name}`, {
        signal: abortController.signal
      }).then(async searchSuggestionResult => {
        const newSearchSuggestions = await searchSuggestionResult.json();

        if (newSearchSuggestions) {
          if (newSearchSuggestions[1].length > 4) {
            newSearchSuggestions[1] = newSearchSuggestions[1].splice(0, 4);
          }

          setSearchSuggestions(newSearchSuggestions);
        }
      }).catch(() => {// If there is an error, just ignore it. There just will be no search suggestions.
      });
    }

    return () => {
      abortController.abort();
    };
  }, [selectedProvider, options, query, searchSuggestions]);
  let currentSuggestion;

  function doSearch(value) {
    const q = encodeURIComponent(value);
    const {
      url
    } = selectedProvider;

    if (url) {
      window.open(`${url}${q}`, options.target || "_blank");
    } else {
      window.open(`${options.url}${q}`, options.target || "_blank");
    }

    setQuery("");
    currentSuggestion = null;
  }

  const handleSearchKeyDown = event => {
    const useSuggestion = searchSuggestions.length && currentSuggestion;

    if (event.key === "Enter") {
      doSearch(useSuggestion ? currentSuggestion : event.target.value);
    }
  };

  if (!availableProviderIds) {
    return null;
  }

  const onChangeProvider = provider => {
    setSelectedProvider(provider);
    localStorage.setItem(localStorageKey, provider.name);
  };

  return /*#__PURE__*/_jsx(ContainerForm, {
    options: options,
    additionalClassNames: "grow information-widget-search",
    children: /*#__PURE__*/_jsx(Raw, {
      children: /*#__PURE__*/_jsxs("div", {
        className: "flex-col relative h-8 my-4 min-w-fit z-20",
        children: [/*#__PURE__*/_jsx("div", {
          className: "flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none w-full text-theme-800 dark:text-white"
        }), /*#__PURE__*/_jsxs(Combobox, {
          value: query,
          children: [/*#__PURE__*/_jsx(Combobox.Input, {
            type: "text",
            className: " overflow-hidden w-full h-full rounded-md text-xs text-theme-900 dark:text-white placeholder-theme-900 dark:placeholder-white/80 bg-white/50 dark:bg-white/10 focus:ring-theme-500 dark:focus:ring-white/50 focus:border-theme-500 dark:focus:border-white/50 border border-theme-300 dark:border-theme-200/50",
            placeholder: t("search.placeholder"),
            onChange: event => {
              setQuery(event.target.value);
            },
            required: true,
            autoCapitalize: "off",
            autoCorrect: "off",
            autoComplete: "off" // eslint-disable-next-line jsx-a11y/no-autofocus
            ,
            autoFocus: options.focus,
            onBlur: e => e.preventDefault(),
            onKeyDown: handleSearchKeyDown
          }), /*#__PURE__*/_jsxs(Listbox, {
            as: "div",
            value: selectedProvider,
            onChange: onChangeProvider,
            className: "relative text-left",
            disabled: availableProviderIds?.length === 1,
            children: [/*#__PURE__*/_jsx("div", {
              children: /*#__PURE__*/_jsxs(Listbox.Button, {
                className: " absolute right-0.5 bottom-0.5 rounded-r-md px-4 py-2 border-1 text-white font-medium text-sm bg-theme-600/40 dark:bg-white/10 focus:ring-theme-500 dark:focus:ring-white/50",
                children: [/*#__PURE__*/_jsx(selectedProvider.icon, {
                  className: "text-white w-3 h-3"
                }), /*#__PURE__*/_jsx("span", {
                  className: "sr-only",
                  children: t("search.search")
                })]
              })
            }), /*#__PURE__*/_jsx(Transition, {
              as: Fragment,
              enter: "transition ease-out duration-100",
              enterFrom: "transform opacity-0 scale-95",
              enterTo: "transform opacity-100 scale-100",
              leave: "transition ease-in duration-75",
              leaveFrom: "transform opacity-100 scale-100",
              leaveTo: "transform opacity-0 scale-95",
              children: /*#__PURE__*/_jsx(Listbox.Options, {
                className: "absolute right-0 z-10 mt-1 origin-top-right rounded-md bg-theme-100 dark:bg-theme-600 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none",
                children: /*#__PURE__*/_jsx("div", {
                  className: "flex flex-col",
                  children: availableProviderIds.map(providerId => {
                    const p = searchProviders[providerId];
                    return /*#__PURE__*/_jsx(Listbox.Option, {
                      value: p,
                      as: Fragment,
                      children: ({
                        active
                      }) => /*#__PURE__*/_jsx("li", {
                        className: classNames("rounded-md cursor-pointer", active ? "bg-theme-600/10 dark:bg-white/10 dark:text-gray-900" : "dark:text-gray-100"),
                        children: /*#__PURE__*/_jsx(p.icon, {
                          className: "h-4 w-4 mx-4 my-2"
                        })
                      })
                    }, providerId);
                  })
                })
              })
            })]
          }), searchSuggestions[1]?.length > 0 && /*#__PURE__*/_jsx(Combobox.Options, {
            className: "mt-1 rounded-md bg-theme-50 dark:bg-theme-800 border border-theme-300 dark:border-theme-200/30 cursor-pointer shadow-lg",
            children: /*#__PURE__*/_jsxs("div", {
              className: "p-1 bg-white/50 dark:bg-white/10 text-theme-900/90 dark:text-white/90 text-xs",
              children: [/*#__PURE__*/_jsx(Combobox.Option, {
                value: query
              }, query), searchSuggestions[1].map(suggestion => /*#__PURE__*/_jsx(Combobox.Option, {
                value: suggestion,
                onClick: () => {
                  doSearch(suggestion);
                },
                className: "flex w-full",
                children: ({
                  active
                }) => {
                  if (active) currentSuggestion = suggestion;
                  return /*#__PURE__*/_jsxs("div", {
                    className: classNames("px-2 py-1 rounded-md w-full flex-nowrap", active ? "bg-theme-300/20 dark:bg-white/10" : ""),
                    children: [/*#__PURE__*/_jsx("span", {
                      className: "whitespace-pre",
                      children: suggestion.indexOf(query) === 0 ? query : ""
                    }), /*#__PURE__*/_jsx("span", {
                      className: "mr-4 whitespace-pre opacity-50",
                      children: suggestion.indexOf(query) === 0 ? suggestion.substring(query.length) : suggestion
                    })]
                  });
                }
              }, suggestion))]
            })
          })]
        })]
      })
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5049:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/widgets/widget/widget_icon.jsx

function widget_icon_WidgetIcon({
  icon,
  size = "s",
  pulse = false
}) {
  const Icon = icon;
  let additionalClasses = "information-widget-icon text-theme-800 dark:text-theme-200 ";

  switch (size) {
    case "m":
      additionalClasses += "w-6 h-6 ";
      break;

    case "l":
      additionalClasses += "w-8 h-8 ";
      break;

    case "xl":
      additionalClasses += "w-10 h-10 ";
      break;

    default:
      additionalClasses += "w-5 h-5 ";
  }

  if (pulse) {
    additionalClasses += "animate-pulse ";
  }

  return /*#__PURE__*/_jsx(Icon, {
    className: additionalClasses
  });
}
;// CONCATENATED MODULE: ./src/components/widgets/widget/primary_text.jsx

function primary_text_PrimaryText({
  children
}) {
  return /*#__PURE__*/_jsx("span", {
    className: "primary-text text-theme-800 dark:text-theme-200 text-sm",
    children: children
  });
}
;// CONCATENATED MODULE: ./src/components/widgets/widget/secondary_text.jsx

function secondary_text_SecondaryText({
  children
}) {
  return /*#__PURE__*/_jsx("span", {
    className: "secondary-text text-theme-800 dark:text-theme-200 text-xs",
    children: children
  });
}
;// CONCATENATED MODULE: ./src/components/widgets/widget/container.jsx







function container_getAllClasses(options, additionalClassNames = "") {
  if (options?.style?.header === "boxedWidgets") {
    if (options?.style?.cardBlur !== undefined) {
      // eslint-disable-next-line no-param-reassign
      additionalClassNames = [additionalClassNames, `backdrop-blur${options.style.cardBlur.length ? "-" : ""}${options.style.cardBlur}`].join(" ");
    }

    return classNames("flex flex-col justify-center ml-2 mr-2", "mt-2 m:mb-0 rounded-md shadow-md shadow-theme-900/10 dark:shadow-theme-900/20 bg-theme-100/20 dark:bg-white/5 p-2 pl-3 pr-3", additionalClassNames);
  }

  let widgetAlignedClasses = "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap";

  if (options?.style?.isRightAligned) {
    widgetAlignedClasses = "flex flex-col justify-center first:ml-auto ml-2 mr-2 ";
  }

  return classNames(widgetAlignedClasses, additionalClassNames);
}
function container_getInnerBlock(children) {
  // children won't be an array if it's Raw component
  return Array.isArray(children) && /*#__PURE__*/_jsxs("div", {
    className: "flex flex-row items-center justify-end widget-inner",
    children: [/*#__PURE__*/_jsx("div", {
      className: "flex flex-col items-center widget-inner-icon",
      children: children.find(child => child.type === WidgetIcon)
    }), /*#__PURE__*/_jsxs("div", {
      className: "flex flex-col ml-3 text-left widget-inner-text",
      children: [children.find(child => child.type === PrimaryText), children.find(child => child.type === SecondaryText)]
    })]
  });
}
function container_getBottomBlock(children) {
  if (children.type !== Raw) {
    return children.find(child => child.type === Raw) || [];
  }

  return [children];
}
function Container({
  children = [],
  options,
  additionalClassNames = ""
}) {
  return /*#__PURE__*/_jsxs("div", {
    className: container_getAllClasses(options, `${additionalClassNames} widget-container`),
    children: [container_getInnerBlock(children), container_getBottomBlock(children)]
  });
}
;// CONCATENATED MODULE: ./src/components/widgets/widget/container_form.jsx


function ContainerForm({
  children = [],
  options,
  additionalClassNames = "",
  callback
}) {
  return /*#__PURE__*/_jsxs("form", {
    type: "button",
    onSubmit: callback,
    className: `${getAllClasses(options, additionalClassNames)} information-widget-form`,
    children: [getInnerBlock(children), getBottomBlock(children)]
  });
}

/***/ }),

/***/ 6217:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var components_widgets_search_search__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7552);
/* harmony import */ var utils_proxy_cached_fetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3643);
/* harmony import */ var utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9124);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_widgets_search_search__WEBPACK_IMPORTED_MODULE_0__, utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_2__]);
([components_widgets_search_search__WEBPACK_IMPORTED_MODULE_0__, utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function handler(req, res) {
  const {
    query,
    providerName
  } = req.query;
  const provider = Object.values(components_widgets_search_search__WEBPACK_IMPORTED_MODULE_0__/* .searchProviders */ .vD).find(({
    name
  }) => name === providerName);

  if (provider.name === "Custom") {
    const widgets = await (0,utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_2__/* .widgetsFromConfig */ .uN)();
    const searchWidget = widgets.find(w => w.type === "search");
    provider.url = searchWidget.options.url;
    provider.suggestionUrl = searchWidget.options.suggestionUrl;
  }

  if (!provider.suggestionUrl) {
    return res.json([query, []]); // Responde with the same array format but with no suggestions.
  }

  return res.send(await (0,utils_proxy_cached_fetch__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(`${provider.suggestionUrl}${encodeURIComponent(query)}`, 5));
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ cachedFetch)
/* harmony export */ });
/* harmony import */ var memory_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2108);
/* harmony import */ var memory_cache__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(memory_cache__WEBPACK_IMPORTED_MODULE_0__);

const defaultDuration = 5;
async function cachedFetch(url, duration) {
  const cached = memory_cache__WEBPACK_IMPORTED_MODULE_0___default().get(url); // eslint-disable-next-line no-param-reassign

  duration = duration || defaultDuration;

  if (cached) {
    return cached;
  } // wrapping text in JSON.parse to handle utf-8 issues


  const data = JSON.parse(await fetch(url).then(res => res.text()));
  memory_cache__WEBPACK_IMPORTED_MODULE_0___default().put(url, data, duration * 1000 * 60);
  return data;
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4574,9124], () => (__webpack_exec__(6217)));
module.exports = __webpack_exports__;

})();