"use strict";
exports.id = 1372;
exports.ids = [1372];
exports.modules = {

/***/ 1372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var _widget_container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(893);
/* harmony import */ var _widget_raw__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9639);
/* harmony import */ var components_resolvedicon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5014);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





function Logo({
  options
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_widget_container__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP, {
    options: options,
    additionalClassNames: `information-widget-logo ${options.icon ? "resolved" : "fallback"}`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_widget_raw__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: options.icon ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "resolved mr-3",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(components_resolvedicon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
          icon: options.icon,
          width: 48,
          height: 48
        })
      }) :
      /*#__PURE__*/
      // fallback to homepage logo
      react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "fallback w-12 h-12",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("svg", {
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 1024 1024",
          style: {
            enableBackground: "new 0 0 1024 1024"
          },
          xmlSpace: "preserve",
          className: "w-full h-full",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("style", {
            children: ".st0{display:none}.st3{stroke-linecap:square}.st3,.st4{fill:none;stroke:#fff;stroke-miterlimit:10}.st6{display:inline;fill:#333}.st7{fill:#fff}"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("g", {
            id: "Icon",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
              d: "M771.9 191c27.7 0 50.1 26.5 50.1 59.3v186.4l-100.2.3V250.3c0-32.8 22.4-59.3 50.1-59.3z",
              style: {
                fill: "rgba(var(--color-logo-start))"
              }
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("linearGradient", {
              id: "homepage_logo_gradient",
              gradientUnits: "userSpaceOnUse",
              x1: 200.746,
              y1: 225.015,
              x2: 764.986,
              y2: 789.255,
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("stop", {
                offset: 0,
                style: {
                  stopColor: "rgba(var(--color-logo-start))"
                }
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("stop", {
                offset: 1,
                style: {
                  stopColor: "rgba(var(--color-logo-stop))"
                }
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("path", {
              d: "M721.8 250.3c0-32.7 22.4-59.3 50.1-59.3H253.1c-27.7 0-50.1 26.5-50.1 59.3v582.2l90.2-75.7-.1-130.3H375v61.8l88-73.8 258.8 217.9V250.6",
              style: {
                fill: "url(#homepage_logo_gradient)"
              }
            })]
          })]
        })
      })
    })
  });
}

/***/ })

};
;