"use strict";
exports.id = 5842;
exports.ids = [5842];
exports.modules = {

/***/ 5842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ OpenWeatherMap)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5744);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_wi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _widget_error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8796);
/* harmony import */ var _widget_container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(893);
/* harmony import */ var _widget_container_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8061);
/* harmony import */ var _widget_primary_text__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2444);
/* harmony import */ var _widget_secondary_text__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4873);
/* harmony import */ var _widget_widget_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4165);
/* harmony import */ var _utils_weather_owm_condition_map__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7267);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















function Widget({
  options
}) {
  const {
    t,
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/openweathermap?${new URLSearchParams(_objectSpread({
    lang: i18n.language
  }, options)).toString()}`);

  if (error || data?.cod === 401 || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_error__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      options: options
    });
  }

  if (!data) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_widget_container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
      options: options,
      additionalClassNames: "information-widget-openweathermap",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_primary_text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        children: t("weather.updating")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_secondary_text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        children: t("weather.wait")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_widget_icon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        icon: react_icons_wi__WEBPACK_IMPORTED_MODULE_2__.WiCloudDown,
        size: "l"
      })]
    });
  }

  const unit = options.units === "metric" ? "celsius" : "fahrenheit";
  const condition = data.weather[0].id;
  const timeOfDay = data.dt > data.sys.sunrise && data.dt < data.sys.sunset ? "day" : "night";
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_widget_container__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP, {
    options: options,
    additionalClassNames: "information-widget-openweathermap",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_widget_primary_text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
      children: [options.label && `${options.label}, `, t("common.number", {
        value: data.main.temp,
        style: "unit",
        unit
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_secondary_text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
      children: data.weather[0].description
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_widget_icon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
      icon: (0,_utils_weather_owm_condition_map__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(condition, timeOfDay),
      size: "xl"
    })]
  });
}

function OpenWeatherMap({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
  const {
    0: location,
    1: setLocation
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: requesting,
    1: setRequesting
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  if (!location && options.latitude && options.longitude) {
    setLocation({
      latitude: options.latitude,
      longitude: options.longitude
    });
  }

  const requestLocation = () => {
    setRequesting(true);

    if (false) {}
  };

  if (!location) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)(_widget_container_button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
      options: options,
      callback: requestLocation,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_primary_text__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        children: t("weather.current")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_secondary_text__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
        children: t("weather.allow")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_widget_widget_icon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        icon: requesting ? react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdLocationSearching : react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdLocationDisabled,
        size: "m",
        pulse: true
      })]
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(Widget, {
    options: _objectSpread(_objectSpread({}, location), options)
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ mapIcon)
/* harmony export */ });
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5744);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_icons_wi__WEBPACK_IMPORTED_MODULE_0__);

const conditions = [{
  code: 200,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayStormShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltStormShowers
  }
}, {
  code: 201,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 202,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 210,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayStormShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltStormShowers
  }
}, {
  code: 211,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 212,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 221,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 230,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayStormShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltStormShowers
  }
}, {
  code: 231,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayStormShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltStormShowers
  }
}, {
  code: 232,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayThunderstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltThunderstorm
  }
}, {
  code: 300,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySprinkle,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSprinkle
  }
}, {
  code: 301,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySprinkle,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSprinkle
  }
}, {
  code: 302,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 310,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySprinkle,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSprinkle
  }
}, {
  code: 311,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 312,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 313,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 314,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 321,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 500,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 501,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 502,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 503,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 504,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRain,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRain
  }
}, {
  code: 511,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySleet,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSleet
  }
}, {
  code: 520,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 521,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 522,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 531,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayShowers,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltShowers
  }
}, {
  code: 600,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 601,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 602,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 611,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySleet,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSleet
  }
}, {
  code: 612,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySleet,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSleet
  }
}, {
  code: 613,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySleet,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSleet
  }
}, {
  code: 615,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRainMix,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRainMix
  }
}, {
  code: 616,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayRainMix,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltRainMix
  }
}, {
  code: 620,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 621,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 622,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySnow,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltSnow
  }
}, {
  code: 701,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayFog,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightFog
  }
}, {
  code: 711,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiSmoke,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiSmoke
  }
}, {
  code: 721,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayHaze,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiWindy
  }
}, {
  code: 731,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust
  }
}, {
  code: 741,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayFog,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightFog
  }
}, {
  code: 751,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust
  }
}, {
  code: 761,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiSandstorm,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiSandstorm
  }
}, {
  code: 762,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDust
  }
}, {
  code: 771,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiStrongWind,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiStrongWind
  }
}, {
  code: 781,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiTornado,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiTornado
  }
}, {
  code: 800,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySunny,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightClear
  }
}, {
  code: 801,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayCloudy,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltCloudy
  }
}, {
  code: 802,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayCloudy,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltCloudy
  }
}, {
  code: 803,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDayCloudy,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiNightAltCloudy
  }
}, {
  code: 804,
  icon: {
    day: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiCloudy,
    night: react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiCloudy
  }
}];
function mapIcon(weatherStatusCode, timeOfDay) {
  const mapping = conditions.find(condition => condition.code === weatherStatusCode);

  if (mapping) {
    if (timeOfDay === "day") {
      return mapping.icon.day;
    }

    if (timeOfDay === "night") {
      return mapping.icon.night;
    }
  }

  return react_icons_wi__WEBPACK_IMPORTED_MODULE_0__.WiDaySunny;
}

/***/ })

};
;