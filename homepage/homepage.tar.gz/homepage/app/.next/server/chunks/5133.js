"use strict";
exports.id = 5133;
exports.ids = [5133];
exports.modules = {

/***/ 9544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ ColorProvider),
/* harmony export */   "d": () => (/* binding */ ColorContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


let lastColor = false;

const getInitialColor = () => {
  if (false) {}

  return "slate"; // slate as the default color;
};

const ColorContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
function ColorProvider({
  initialTheme,
  children
}) {
  const {
    0: color,
    1: setColor
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getInitialColor);

  const rawSetColor = rawColor => {
    const root = window.document.getElementById("page_wrapper");
    root.classList.remove(`theme-${lastColor}`);
    root.classList.add(`theme-${rawColor}`);
    localStorage.setItem("theme-color", rawColor);
    lastColor = rawColor;
  };

  if (initialTheme) {
    rawSetColor(initialTheme);
  }

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    rawSetColor(color);
  }, [color]);
  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    color,
    setColor
  }), [color]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(ColorContext.Provider, {
    value: value,
    children: children
  });
}

/***/ }),

/***/ 635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ SettingsContext),
/* harmony export */   "m": () => (/* binding */ SettingsProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


const SettingsContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
function SettingsProvider({
  initialSettings,
  children
}) {
  const {
    0: settings,
    1: setSettings
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});

  if (initialSettings) {
    setSettings(initialSettings);
  }

  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    settings,
    setSettings
  }), [settings]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(SettingsContext.Provider, {
    value: value,
    children: children
  });
}

/***/ }),

/***/ 5496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ TabContext),
/* harmony export */   "s": () => (/* binding */ TabProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


const TabContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
function TabProvider({
  initialTab,
  children
}) {
  const {
    0: activeTab,
    1: setActiveTab
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  if (initialTab) {
    setActiveTab(initialTab);
  }

  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    activeTab,
    setActiveTab
  }), [activeTab]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(TabContext.Provider, {
    value: value,
    children: children
  });
}

/***/ }),

/***/ 4006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ ThemeContext),
/* harmony export */   "f": () => (/* binding */ ThemeProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const getInitialTheme = () => {
  if (false) {}

  return "dark"; // dark as the default mode
};

const ThemeContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();
function ThemeProvider({
  initialTheme,
  children
}) {
  const {
    0: theme,
    1: setTheme
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getInitialTheme);

  const rawSetTheme = rawTheme => {
    const root = window.document.getElementById("page_wrapper");
    const isDark = rawTheme === "dark";
    root.classList.remove(isDark ? "light" : "dark");
    root.classList.add(rawTheme);
    localStorage.setItem("theme-mode", rawTheme);
  };

  if (initialTheme) {
    rawSetTheme(initialTheme);
  }

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    rawSetTheme(theme);
  }, [theme]);
  const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => ({
    theme,
    setTheme
  }), [theme]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(ThemeContext.Provider, {
    value: value,
    children: children
  });
}

/***/ })

};
;