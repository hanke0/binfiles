"use strict";
exports.id = 6357;
exports.ids = [6357];
exports.modules = {

/***/ 6357:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Integration)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2353);
/* harmony import */ var cal_parser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3985);
/* harmony import */ var cal_parser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cal_parser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rrule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7807);
/* harmony import */ var rrule__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rrule__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1056);
/* harmony import */ var _components_services_widget_error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5659);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([luxon__WEBPACK_IMPORTED_MODULE_0__, _utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_5__]);
([luxon__WEBPACK_IMPORTED_MODULE_0__, _utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







 // https://gist.github.com/jlevy/c246006675becc446360a798e2b2d781



function simpleHash(str) {
  /* eslint-disable no-plusplus, no-bitwise */
  let hash = 0;

  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i) | 0;
  }

  return (hash >>> 0).toString(36);
  /* eslint-disable no-plusplus, no-bitwise */
}

function Integration({
  config,
  params,
  setEvents,
  hideErrors,
  timezone
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
  const {
    data: icalData,
    error: icalError
  } = (0,_utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(config, config.name, {
    refreshInterval: 300000 // 5 minutes

  });
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
    let parsedIcal;

    if (!icalError && icalData && !icalData.error) {
      parsedIcal = (0,cal_parser__WEBPACK_IMPORTED_MODULE_1__.parseString)(icalData.data);

      if (parsedIcal.events.length === 0) {
        icalData.error = {
          message: `'${config.name}': ${t("calendar.noEventsFound")}`
        };
      }
    }

    const startDate = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromISO(params.start);
    const endDate = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromISO(params.end);

    if (icalError || !parsedIcal || !startDate.isValid || !endDate.isValid) {
      return;
    }

    const eventsToAdd = {};
    const events = parsedIcal?.getEventsBetweenDates(startDate.toJSDate(), endDate.toJSDate());
    const now = timezone ? luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.now().setZone(timezone) : luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.now();
    events?.forEach(event => {
      let title = `${event?.summary?.value}`;

      if (config?.params?.showName) {
        title = `${config.name}: ${title}`;
      }

      const eventToAdd = (date, i, type) => {
        const duration = event.dtend.value - event.dtstart.value;
        const days = duration / (1000 * 60 * 60 * 24);
        const eventDate = timezone ? luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromJSDate(date, {
          zone: timezone
        }) : luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromJSDate(date);

        for (let j = 0; j < days; j += 1) {
          // See https://github.com/gethomepage/homepage/issues/2753 uid is not stable
          // assumption is that the event is the same if the start, end and title are all the same
          const hash = simpleHash(`${event?.dtstart?.value}${event?.dtend?.value}${title}${i}${j}${type}}`);
          eventsToAdd[hash] = {
            title,
            date: eventDate.plus({
              days: j
            }),
            color: config?.color ?? "zinc",
            isCompleted: eventDate < now,
            additional: event.location?.value,
            type: "ical"
          };
        }
      };

      const recurrenceOptions = event?.recurrenceRule?.origOptions;

      if (recurrenceOptions && Object.keys(recurrenceOptions).length !== 0) {
        try {
          const rule = new rrule__WEBPACK_IMPORTED_MODULE_4__.RRule(recurrenceOptions);
          const recurringEvents = rule.between(startDate.toJSDate(), endDate.toJSDate());
          recurringEvents.forEach((date, i) => eventToAdd(date, i, "recurring"));
          return;
        } catch (e) {
          // eslint-disable-next-line no-console
          console.error("Unable to parse recurring events from iCal: %s", e);
        }
      }

      event.matchingDates.forEach((date, i) => eventToAdd(date, i, "single"));
    });
    setEvents(prevEvents => _objectSpread(_objectSpread({}, prevEvents), eventsToAdd));
  }, [icalData, icalError, config, params, setEvents, timezone, t]);
  const error = icalError ?? icalData?.error;
  return error && !hideErrors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_services_widget_error__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
    error: {
      message: `${config.type}: ${error.message ?? error}`
    }
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;