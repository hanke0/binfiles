"use strict";
exports.id = 3471;
exports.ids = [3471];
exports.modules = {

/***/ 8061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContainerButton)
/* harmony export */ });
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(893);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


function ContainerButton({
  children = [],
  options,
  additionalClassNames = "",
  callback
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("button", {
    type: "button",
    onClick: callback,
    className: `${(0,_container__WEBPACK_IMPORTED_MODULE_0__/* .getAllClasses */ .Ld)(options, additionalClassNames)} information-widget-container-button`,
    children: [(0,_container__WEBPACK_IMPORTED_MODULE_0__/* .getInnerBlock */ .w_)(children), (0,_container__WEBPACK_IMPORTED_MODULE_0__/* .getBottomBlock */ .TS)(children)]
  });
}

/***/ }),

/***/ 8796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Error)
/* harmony export */ });
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(893);
/* harmony import */ var _primary_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2444);
/* harmony import */ var _widget_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4165);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







function Error({
  options
}) {
  const {
    t
  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_0__.useTranslation)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
    options: options,
    additionalClassNames: "information-widget-error",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_primary_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      children: t("widget.api_error")
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_widget_icon__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
      icon: react_icons_bi__WEBPACK_IMPORTED_MODULE_1__.BiError,
      size: "l"
    })]
  });
}

/***/ })

};
;