"use strict";
exports.id = 1628;
exports.ids = [1628];
exports.modules = {

/***/ 1628:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Component)
/* harmony export */ });
/* harmony import */ var components_services_widget_container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7864);
/* harmony import */ var components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5113);
/* harmony import */ var utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1056);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_2__]);
utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Component({
  service
}) {
  const {
    widget
  } = service;
  const {
    tuner = 0
  } = widget;
  const {
    data: channelsData,
    error: channelsError
  } = (0,utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(widget, "lineup");
  const {
    data: statusData,
    error: statusError
  } = (0,utils_proxy_use_widget_api__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(widget, "status");

  if (channelsError || statusError) {
    const finalError = channelsError ?? statusError;
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_container__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
      service: service,
      error: finalError
    });
  }

  if (!channelsData || !statusData) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
      service: service,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        label: "hdhomerun.channels"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        label: "hdhomerun.hd"
      })]
    });
  } // Provide a default if not set in the config


  if (!widget.fields) {
    widget.fields = ["channels", "hd"];
  } // Limit to a maximum of 4 at a time


  if (widget.fields.length > 4) {
    widget.fields = widget.fields.slice(0, 4);
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
    service: service,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.channels",
      value: channelsData?.length
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.hd",
      value: channelsData?.filter(channel => channel.HD === 1)?.length
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.tunerCount",
      value: `${statusData?.filter(num => num.VctNumber != null).length ?? 0} / ${statusData?.length ?? 0}`
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.channelNumber",
      value: statusData[tuner]?.VctNumber ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.channelNetwork",
      value: statusData[tuner]?.VctName ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.signalStrength",
      value: statusData[tuner]?.SignalStrengthPercent ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.signalQuality",
      value: statusData[tuner]?.SignalQualityPercent ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.symbolQuality",
      value: statusData[tuner]?.SymbolQualityPercent ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.clientIP",
      value: statusData[tuner]?.TargetIP ?? null
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      label: "hdhomerun.networkRate",
      value: statusData[tuner]?.NetworkRate ?? null
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;