#!/usr/bin/env bash

node server.js
