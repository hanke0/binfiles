#!/bin/sh

node server.js
