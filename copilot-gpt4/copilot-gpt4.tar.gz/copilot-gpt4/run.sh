#!/bin/sh

export HOST=localhost
export PORT=10023
export CACHE=true
export CACHE_PATH=./cache.db

copilot-gpt4
