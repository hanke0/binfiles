#!/bin/bash

yarn start
