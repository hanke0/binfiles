# Placeholder, can be mounted in a Docker container with a custom settings

# ALLOW_REGISTRATION = True
